<?php $__env->startSection('content'); ?>

		<div class="text-center">
	    
	    </div>
	    <h5 class="text-center m-t" style="text-transform: uppercase;"> <?php echo e(config('sximo.cnf_appdesc')); ?>  </h5> 
				
	
 <?php echo Form::open(array('url'=>'user/create', 'class'=>'form-signup','parsley-validate'=>'','novalidate'=>' ','id'=>'register-form' )); ?>

	    	<?php if(Session::has('message')): ?>
				<?php echo Session::get('message'); ?>

			<?php endif; ?>
		<ul class="parsley-error-list">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

	<div class="form-group has-feedback">
		
	  <?php echo Form::text('username', null, array('class'=>'form-control','required'=>'true'  ,'placeholder'=> __('core.username') )); ?>

		
	</div>	
	<div class="form-group has-feedback row">
		<div class="col-md-6">
		
		  <?php echo Form::text('firstname', null, array('class'=>'form-control','required'=>'true' ,'placeholder'=> __('core.firstname') )); ?>

			
		</div>
		<div class="col-md-6">
			
		 <?php echo Form::text('lastname', null, array('class'=>'form-control', 'required'=>'' ,'placeholder'=> __('core.lastname') )); ?>

			
		</div>	
	</div>
	
	
	<div class="form-group has-feedback">
	 <?php echo Form::text('email', null, array('class'=>'form-control', 'required'=>'true','placeholder'=> __('core.email'))); ?>

	</div>

	<div class="form-group has-feedback row">
		<div class="col-md-6">
			
	 		<?php echo Form::password('password', array('class'=>'form-control','required'=>'true' ,'placeholder'=> __('core.password'))); ?>

			
		</div>
		<div class="col-md-6">
			
			<?php echo Form::password('password_confirmation', array('class'=>'form-control','required'=>'true' ,'placeholder'=> __('core.repassword'))); ?>

			
		</div>	
	</div>

		<?php if(config('sximo.cnf_recaptcha') =='true'): ?> 
		<div class="form-group has-feedback  animated fadeInLeft delayp1">
			<label class="text-left"> Are u human ? </label>	
			<div class="g-recaptcha" data-sitekey="6Le2bjQUAAAAABascn2t0WsRjZbmL6EnxFJUU1H_"></div>
			
			<div class="clr"></div>
		</div>	
	 	<?php endif; ?>						

      <div class="row form-group">
        <div class="col-sm-12">
          <button type="submit" style="width:100%;" class="btn btn-primary pull-right"><i class="icon-user-plus"></i> <?php echo app('translator')->getFromJson('core.signup'); ?>	</button>
       </div>
      </div>
	  <p style="padding:10px 0" class="text-center">
	  <a href="<?php echo e(URL::to('user/login')); ?>"> <?php echo app('translator')->getFromJson('core.signin'); ?>   </a> | <a href="<?php echo e(URL::to('')); ?>"> <?php echo app('translator')->getFromJson('core.backtosite'); ?>   </a> 
   		</p>
 <?php echo Form::close(); ?>


<script type="text/javascript">
	$(document).ready(function(){
		$('#register-form').parsley();
	})
</script>		
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>