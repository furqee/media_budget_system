<?php

return array(
// General 
	"name" => "No Record Found",
	"method" => "Create New",

	)