
<p> This is example how to fill form configuration </p>
<div class="">
	<ul>
		<li>
			<a href="javascript://ajax" data-value="value:display , value1:display1 "> Option select custom
			<br /> <b>Single Choice</b> <code> options=value:display , value1:display1 </code>
			<br /> <b>Multiple Choice</b> <code> options=value:display , value1:display1|multiple:true </code>
			</a>
		</li>
		<li>
		<a href="javascript://ajax" data-value="tb_name:key:field-field2 "> Option select database
			<br /> <b>Single Choice</b><code> lookup=tb_name:key:field-field2 </code> 
			<br /> <b>Multiple Choice</b> <code> lookup=tb_name:key:field-field2|multiple:true </code>
		</a>
		</li>
		<li><a href="javascript://ajax" data-value="value:display , value1:display1 "> Option checkbox / Radio 
			<br /><code> options=value:display , value1:display1 </code>
			</a>
		</li>
		<li><a href="javascript://ajax" data-value="value:display , value1:display1 "> Upload File 
			<br /><b>Single Upload</b> <code>type=image|path=/uploads/path/ </code>
			<br /><b>Multi Upload</b> <code> type=image|path=/uploads/path/|multiple:true  </code>
		</a></li>
		<li>
			<a href="javascript://ajax" data-value="value:display , value1:display1 "> Upload Image 
			<br /><b>Single Upload</b> <code> type=file|/uploads/path/ </code>
			<br /><b>Multi Upload</b> <code> type=file|/uploads/path/|multiple:true  </code>
			</a>
		</li>
	</ul>
	<hr />
	
</div>
