<div class="home-banner">
	<div class="container">
		<div class="row">
			  	
			  	<p>Need to create application fast and powerfull ? </p>
			      <h2>Sximo 5 is your Soulution</h2>
			      <p >Create a website that you are gonna be proud of. Build anything with Sximo 5.</p>
			      <button  class="btn btn-success btn-sm">Getting Started</button>
			  	
	  </div>
	</div>  
</div>
<section class="info-bar">
	<div class="container">
			<div class="row">
					<div class="col-md-4 col-xs-12">
						
						<h3>COMPONENTS GENERATOR</h3>
						<p>Nullam id dolor id nibh ultricies vehicula ut id elit</p>
					</div>

					<div class="col-md-4 col-xs-12">
						
						<h3>CRUD BUILDER INSIDE </h3>
						<p>Nullam id dolor id nibh ultricies vehicula ut id elit</p>
					</div>

					<div class="col-md-4 col-xs-12">
						
						<h3>PAGES GENERATOR</h3>
						<p>Nullam id dolor id nibh ultricies vehicula ut id elit</p>
					</div>

			</div>
		</div>
</section>
	
<section class="bg-grey">
	<div class=" container">
	<div class="row">	
	  	<div class="col-md-3 col-xs-12">
	  		<div class="box-content">	
		  	 	<h3>Based On VueJS</h3>
		  	 	<p>
		  	 		Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.
		  	 	</p> 
		  	 	<p> <a href="#"> Details ... </a> </p>
		  	 </div>
	  	</div>
	  	<div class="col-md-3 col-xs-12">
	  		<div class="box-content">	
		  	  	<h3>Based On  Codeigniter Framework</h3>
		  	 	<p>
		  	 		Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.
		  	 	</p> 
		  	 	<p> <a href="#"> Details ... </a> </p>
		  	</div> 	
	  	</div>
	  	<div class="col-md-3 col-xs-12">
	  		<div class="box-content">	
		  	  	<h3> Based On  Crudengine CLASS</h3>
		  	 	<p>
		  	 		Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.
		  	 	</p> 
		  	 	<p> <a href="#"> Details ... </a> </p>
		  	</div> 	
	  	</div>
	  	<div class="col-md-3 col-xs-12">
	  		<div class="box-content">	
		  	  	<h3> Based On  SPA / PWA Ability</h3>
		  	 	<p>
		  	 		Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.
		  	 	</p> 
		  	 	<p> <a href="#"> Details ... </a> </p>
		  	</div> 	
	  	</div>
	</div>
	</div>
</section>

<section >
	<div class="text-center ">
  		<h2 class="fs-30">Rich features <br />
				with many custom components</h2>
		<p class="fs-18">Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.</p>					
	</div>	
  		<div class="container">
  			<div class="row">
	  			<div class="col-md-3 col-xs-12">
	  				<div class="box mb-3">

	  					<h3>Full responsive</h3>
	  					<p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.</p>
	  				</div>
	  				<div class="box">

	  					<h3>Full responsive</h3>
	  					<p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.</p>
	  				</div>
	  			  
	  			</div>
	  			<div class="col-md-6">
	  				<img src="{{ asset('frontend/default/images/perspective.png') }}" width="100%" />
	  			  
	  			</div>
	  			<div class="col-md-3 col-xs-12">
	  				<div class="box mb-2">

	  					<h3>Full responsive</h3>
	  					<p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.</p>
	  				</div>
	  				<div class="box">

	  					<h3>Full responsive</h3>
	  					<p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus.</p>
	  				</div>
	  			  
	  			</div>
	  		</div>
	  	</div>	
	  	

  </section>


  <section class="bg-grey text-center ">
  		<h2 class="fs-30">Our Team</h2>
  		<p class="fs-18 mb-5">Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.</p>
  		<div class=" container">
  			<div class="row">
	  			<div class="col-md-4">
	  				<div class="team-member">
	  					<img src="{{ asset('frontend/default/images/avatar2.jpg') }}" class="img-circle" />
	  				</div>
	  				<h3>Amelia Smith </h3>
					<p>orem ipsum dolor sit amet, illum fastidii dissentias quo ne. Sea ne sint animal iisque, nam an soluta sensibus.</p>	
	  			</div>
	  			<div class="col-md-4">
	  				<div class="team-member">
	  					<img src="{{ asset('frontend/default/images/avatar3.jpg') }}"  class="img-circle" />
	  				</div>
	  				<h3>Amelia Smith </h3>
					<p>orem ipsum dolor sit amet, illum fastidii dissentias quo ne. Sea ne sint animal iisque, nam an soluta sensibus.</p>	
	  			</div>
	  			<div class="col-md-4">
	  				<div class="team-member">
	  					<img src="{{ asset('frontend/default/images/avatar1.jpg') }}"  class="img-circle" />
	  				</div>
	  				<h3>Amelia Smith </h3>
					<p>orem ipsum dolor sit amet, illum fastidii dissentias quo ne. Sea ne sint animal iisque, nam an soluta sensibus.</p>	
	  			</div>
	  		</div>	
  		</div>		


  </section>

