@extends('layouts.app')

@section('content')
<div class="page-content row"> 
	<div class="page-content-wrapper m-t">
		<div class="sbox"  >
			<div class="sbox-content">
				<?php echo $content ;?>
			</div>	
		</div>
	</div>		
</div>
  
@endsection
