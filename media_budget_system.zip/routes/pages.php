<?php 
Route::get('service', 'HomeController@index');
Route::get('about-us', 'HomeController@index');
Route::get('contact-us', 'HomeController@index');
Route::get('privacy', 'HomeController@index');
Route::get('new-sximo-5-ultimate-powefull-cms', 'HomeController@index');
Route::get('toc', 'HomeController@index');
Route::get('printing-and-typesetting-industry', 'HomeController@index');
Route::get('new-sximo-5.1.6-sept-2016', 'HomeController@index');
Route::get('-remaining-essentially-unchanged', 'HomeController@index');
Route::get('page-backend', 'HomeController@index');
Route::get('gallery', 'HomeController@index');
Route::get('faq', 'HomeController@index');
Route::get('galleries', 'HomeController@index');
Route::get('portpolio', 'HomeController@index');
Route::get('team', 'HomeController@index');
?>