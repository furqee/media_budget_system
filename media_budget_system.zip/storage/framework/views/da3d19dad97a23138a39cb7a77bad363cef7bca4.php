<?php $__env->startSection('content'); ?>
<section class="page-header row">
	<h2> <?php echo e($pageTitle); ?> <small> <?php echo e($pageNote); ?> </small></h2>
	<ol class="breadcrumb">
		<li><a href="<?php echo e(url('')); ?>"> Dashboard </a></li>
		<li><a href="<?php echo e(url($pageModule)); ?>"> <?php echo e($pageTitle); ?> </a></li>
		<li class="active"> Form  </li>		
	</ol>
</section>
<div class="page-content  row">
	<div class="page-content-wrapper no-margin">

	<div class="sbox">
		<div class="sbox-title clearfix">
		<h4> Form Update </h4>
			<div class="sbox-tools" >
				<a href="<?php echo e(url('sximo/rac?return='.$return)); ?>" class="tips btn btn-sm  " title="<?php echo e(__('core.btn_back')); ?>"><i class="fa  fa-times"></i></a>		
			</div>
		</div>
		<div class="sbox-content">
	<div class="box-body"> 	

		<ul class="parsley-error-list">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>	

		 <?php echo Form::open(array('url'=>'sximo/rac?return='.$return, 'class'=>'form-horizontal validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ')); ?>

<div class="col-md-12">
						<fieldset><legend> RestAPI Client</legend>
				<?php echo Form::hidden('id', $row['id']); ?>					
									  <div class="form-group  " >
										<label for="Apiuser" class=" control-label col-md-4 text-left"> Apiuser </label>
										<div class="col-md-7">
										  <select name='apiuser' rows='5' id='apiuser' class='select2 ' required="true"   ></select> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
										<?php if($row['id'] !=''): ?>
											<div class="form-group  " >
												<label for="Apikey" class=" control-label col-md-4 text-left"> 
												Api Key </label>
												<div class="col-md-6">
												  <?php echo Form::text('apikey', $row['apikey'],array('class'=>'form-control', 'placeholder'=>'','readonly'=>'1' ,'style'=>'background : #f0f0f0 !important;'   )); ?> 
												 <p><i>  Use this apikey with useremail as basic authorization access to all your registered modules </i> </p>
												 </div> 
												 <div class="col-md-2">
												 	
												 </div>
											</div> 
										<?php endif; ?>
	 <?php echo Form::hidden('created', $row['created']); ?>					
									  <div class="form-group  " >
										<label for="Modules" class=" control-label col-md-4 text-left"> Modules </label>
										<div class="col-md-7">
										  <select name='modules[]' multiple rows='5' id='modules' required="true" class='select2 '   ></select> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> </fieldset>
			</div>
			
			

		
			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="icon-checkmark-circle2"></i> <?php echo e(__('core.sb_apply')); ?></button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="icon-bubble-check"></i> <?php echo e(__('core.sb_save')); ?></button>
					<button type="button" onclick="location.href='<?php echo e(URL::to('sximo/rac?return='.$return)); ?>' " class="btn btn-warning btn-sm "><i class="icon-cancel-circle2 "></i>  <?php echo e(__('core.sb_cancel')); ?> </button>
					</div>	  
			
				  </div> 
		 <input type="hidden" name="action_task" value="save" />
		 <?php echo Form::close(); ?>

	</div>
</div>		 
</div>	
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#apiuser").jCombo("<?php echo url('sximo/rac/comboselect?filter=tb_users:id:email'); ?>",
		{  selected_value : '<?php echo e($row["apiuser"]); ?>' });
		
		$("#modules").jCombo("<?php echo url('sximo/rac/comboselect?filter=tb_module:module_name:module_title&limit=WHERE:module_type:!=:core'); ?>",
		{  selected_value : '<?php echo e($row["modules"]); ?>' });	
		
	});
	</script>		 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>