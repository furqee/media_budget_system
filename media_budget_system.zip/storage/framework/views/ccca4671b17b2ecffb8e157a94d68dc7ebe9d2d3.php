<?php $__env->startSection('content'); ?>
<section class="page-header row">
   <h2> <?php echo e($pageTitle); ?> <small> <?php echo e($pageNote); ?> </small></h2>
   <ol class="breadcrumb">
      <li><a href="<?php echo e(url('')); ?>"> Dashboard </a></li>
      <li><a href="<?php echo e(url($pageModule)); ?>"> <?php echo e($pageTitle); ?> </a></li>
      <li class="active"> Form  </li>
   </ol>
</section>
<div class="page-content row">
   <div class="page-content-wrapper no-margin">
      <?php echo Form::open(array('url'=>'adplatforms?return='.$return, 'class'=>'form-horizontal validated','files' => true )); ?>

      <div class="sbox">
         <div class="sbox-title clearfix">
            <div class="sbox-tools " >
               <a href="<?php echo e(url($pageModule.'?return='.$return)); ?>" class="tips btn btn-sm "  title="<?php echo e(__('core.btn_back')); ?>" ><i class="fa  fa-times"></i></a> 
            </div>
            <div class="sbox-tools pull-left" >
               <!-- <button name="apply" class="tips btn btn-sm btn-default  "  title="<?php echo e(__('core.btn_back')); ?>" ><i class="fa  fa-check"></i> <?php echo e(__('core.sb_apply')); ?> </button> -->
               <button name="save" class="tips btn btn-sm btn-default"  title="<?php echo e(__('core.btn_back')); ?>" ><i class="fa  fa-paste"></i> <?php echo e(__('core.sb_save')); ?> </button> 
            </div>
         </div>
         <div class="sbox-content clearfix">
            <ul class="parsley-error-list">
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="col-md-12">
               <fieldset>
                  <legend> Ad Platforms</legend>
                  <?php echo Form::hidden('id', $row['id']); ?>					
                  <div class="form-group  " >
                     <label for="Platform" class=" control-label col-md-4 text-left"> Platform <span class="asterix"> * </span></label>
                     <div class="col-md-6">
                        <input  type='text' name='platform' id='platform' value='<?php echo e($row['platform']); ?>' 
                        required     class='form-control input-sm ' /> 
                     </div>
                     <div class="col-md-2">
                     </div>
                  </div>
                  <?php echo Form::hidden('created_at', $row['created_at']); ?>

               </fieldset>
            </div>
         </div>
      </div>
      <input type="hidden" name="action_task" value="save" />
      <?php echo Form::close(); ?>

   </div>
</div>
<script type="text/javascript">
   $(document).ready(function() { 
   	
   	
   	 		 
   
   	$('.removeMultiFiles').on('click',function(){
   		var removeUrl = '<?php echo e(url("adplatforms/removefiles?file=")); ?>'+$(this).attr('url');
   		$(this).parent().remove();
   		$.get(removeUrl,function(response){});
   		$(this).parent('div').empty();	
   		return false;
   	});		
   	
   });
</script>		 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>