<?php $__env->startSection('content'); ?>
<section class="page-header row">
	<h2> <?php echo e($pageTitle); ?> <small> <?php echo e($pageNote); ?> </small></h2>
	<ol class="breadcrumb">
		<li><a href="<?php echo e(url('')); ?>"> Dashboard </a></li>
		<li><a href="<?php echo e(url($pageModule)); ?>"> <?php echo e($pageTitle); ?> </a></li>
		<li class="active"> View  </li>		
	</ol>
</section>
<div class="page-content row">
	<div class="page-content-wrapper no-margin">
	
	<div class="sbox">
		<div class="sbox-title clearfix">
			<div class="sbox-tools pull-left" >
		   		<a href="<?php echo e(($prevnext['prev'] != '' ? url('clients/'.$prevnext['prev'].'?return='.$return ) : '#')); ?>" class="tips btn btn-sm"><i class="fa fa-arrow-left"></i>  </a>	
				<a href="<?php echo e(($prevnext['next'] != '' ? url('clients/'.$prevnext['next'].'?return='.$return ) : '#')); ?>" class="tips btn btn-sm "> <i class="fa fa-arrow-right"></i>  </a>					
			</div>	

			<div class="sbox-tools" >
				<?php if($access['is_add'] ==1): ?>
		   		<a href="<?php echo e(url('clients/'.$id.'/edit?return='.$return)); ?>" class="tips btn btn-sm  " title="<?php echo e(__('core.btn_edit')); ?>"><i class="fa  fa-pencil"></i></a>
				<?php endif; ?>
				<a href="<?php echo e(url('clients?return='.$return)); ?>" class="tips btn btn-sm  " title="<?php echo e(__('core.btn_back')); ?>"><i class="fa  fa-times"></i></a>		
			</div>
		</div>
		<div class="sbox-content">
			<div class="table-responsive">
				<table class="table table-striped " >
					<tbody>	
				
					<tr>
						<td width='30%' class='label-view text-right'><?php echo e(SiteHelpers::activeLang('Name', (isset($fields['name']['language'])? $fields['name']['language'] : array()))); ?></td>
						<td><?php echo e($row->name); ?> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'><?php echo e(SiteHelpers::activeLang('Email', (isset($fields['email']['language'])? $fields['email']['language'] : array()))); ?></td>
						<td><?php echo e($row->email); ?> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'><?php echo e(SiteHelpers::activeLang('Address', (isset($fields['address']['language'])? $fields['address']['language'] : array()))); ?></td>
						<td><?php echo e($row->address); ?> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'><?php echo e(SiteHelpers::activeLang('Website', (isset($fields['website']['language'])? $fields['website']['language'] : array()))); ?></td>
						<td><?php echo e($row->website); ?> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'><?php echo e(SiteHelpers::activeLang('FB Page Link', (isset($fields['fb_page_link']['language'])? $fields['fb_page_link']['language'] : array()))); ?></td>
						<td><?php echo e($row->fb_page_link); ?> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'><?php echo e(SiteHelpers::activeLang('Insta Link', (isset($fields['insta_link']['language'])? $fields['insta_link']['language'] : array()))); ?></td>
						<td><?php echo e($row->insta_link); ?> </td>
						
					</tr>
				
					</tbody>	
				</table>   

			 	

			</div>
		</div>
	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>