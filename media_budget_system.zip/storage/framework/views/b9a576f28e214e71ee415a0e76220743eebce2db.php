<div class="feather-icons row text-center">
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-glass3"></i></div>
      <label class="fonticon-classname">icon-glass3</label>
      <label class="fonticon-unit">f000</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-music2"></i></div>
      <label class="fonticon-classname">icon-music2</label>
      <label class="fonticon-unit">f001</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-search5"></i></div>
      <label class="fonticon-classname">icon-search5</label>
      <label class="fonticon-unit">f002</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-envelope-o"></i></div>
      <label class="fonticon-classname">icon-envelope-o</label>
      <label class="fonticon-unit">f003</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-heart4"></i></div>
      <label class="fonticon-classname">icon-heart4</label>
      <label class="fonticon-unit">f004</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-star4"></i></div>
      <label class="fonticon-classname">icon-star4</label>
      <label class="fonticon-unit">f005</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-star-o"></i></div>
      <label class="fonticon-classname">icon-star-o</label>
      <label class="fonticon-unit">f006</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-user4"></i></div>
      <label class="fonticon-classname">icon-user4</label>
      <label class="fonticon-unit">f007</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-film2"></i></div>
      <label class="fonticon-classname">icon-film2</label>
      <label class="fonticon-unit">f008</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-th-large"></i></div>
      <label class="fonticon-classname">icon-th-large</label>
      <label class="fonticon-unit">f009</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-th"></i></div>
      <label class="fonticon-classname">icon-th</label>
      <label class="fonticon-unit">f00a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-th-list"></i></div>
      <label class="fonticon-classname">icon-th-list</label>
      <label class="fonticon-unit">f00b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-check"></i></div>
      <label class="fonticon-classname">icon-check</label>
      <label class="fonticon-unit">f00c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-close2"></i></div>
      <label class="fonticon-classname">icon-close2</label>
      <label class="fonticon-unit">f00d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-remove"></i></div>
      <label class="fonticon-classname">icon-remove</label>
      <label class="fonticon-unit">f00d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-times"></i></div>
      <label class="fonticon-classname">icon-times</label>
      <label class="fonticon-unit">f00d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-search-plus"></i></div>
      <label class="fonticon-classname">icon-search-plus</label>
      <label class="fonticon-unit">f00e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-search-minus"></i></div>
      <label class="fonticon-classname">icon-search-minus</label>
      <label class="fonticon-unit">f010</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-power-off"></i></div>
      <label class="fonticon-classname">icon-power-off</label>
      <label class="fonticon-unit">f011</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-signal"></i></div>
      <label class="fonticon-classname">icon-signal</label>
      <label class="fonticon-unit">f012</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cog2"></i></div>
      <label class="fonticon-classname">icon-cog2</label>
      <label class="fonticon-unit">f013</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gear"></i></div>
      <label class="fonticon-classname">icon-gear</label>
      <label class="fonticon-unit">f013</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-trash-o"></i></div>
      <label class="fonticon-classname">icon-trash-o</label>
      <label class="fonticon-unit">f014</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-home4"></i></div>
      <label class="fonticon-classname">icon-home4</label>
      <label class="fonticon-unit">f015</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-o"></i></div>
      <label class="fonticon-classname">icon-file-o</label>
      <label class="fonticon-unit">f016</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-clock-o"></i></div>
      <label class="fonticon-classname">icon-clock-o</label>
      <label class="fonticon-unit">f017</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-road2"></i></div>
      <label class="fonticon-classname">icon-road2</label>
      <label class="fonticon-unit">f018</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-download4"></i></div>
      <label class="fonticon-classname">icon-download4</label>
      <label class="fonticon-unit">f019</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-o-down"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-o-down</label>
      <label class="fonticon-unit">f01a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-o-up"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-o-up</label>
      <label class="fonticon-unit">f01b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-inbox"></i></div>
      <label class="fonticon-classname">icon-inbox</label>
      <label class="fonticon-unit">f01c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-play-circle-o"></i></div>
      <label class="fonticon-classname">icon-play-circle-o</label>
      <label class="fonticon-unit">f01d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-repeat"></i></div>
      <label class="fonticon-classname">icon-repeat</label>
      <label class="fonticon-unit">f01e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rotate-right"></i></div>
      <label class="fonticon-classname">icon-rotate-right</label>
      <label class="fonticon-unit">f01e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-refresh2"></i></div>
      <label class="fonticon-classname">icon-refresh2</label>
      <label class="fonticon-unit">f021</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-list-alt"></i></div>
      <label class="fonticon-classname">icon-list-alt</label>
      <label class="fonticon-unit">f022</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-lock2"></i></div>
      <label class="fonticon-classname">icon-lock2</label>
      <label class="fonticon-unit">f023</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-flag3"></i></div>
      <label class="fonticon-classname">icon-flag3</label>
      <label class="fonticon-unit">f024</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-headphones2"></i></div>
      <label class="fonticon-classname">icon-headphones2</label>
      <label class="fonticon-unit">f025</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-volume-off"></i></div>
      <label class="fonticon-classname">icon-volume-off</label>
      <label class="fonticon-unit">f026</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-volume-down"></i></div>
      <label class="fonticon-classname">icon-volume-down</label>
      <label class="fonticon-unit">f027</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-volume-up"></i></div>
      <label class="fonticon-classname">icon-volume-up</label>
      <label class="fonticon-unit">f028</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-qrcode2"></i></div>
      <label class="fonticon-classname">icon-qrcode2</label>
      <label class="fonticon-unit">f029</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-barcode2"></i></div>
      <label class="fonticon-classname">icon-barcode2</label>
      <label class="fonticon-unit">f02a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tag"></i></div>
      <label class="fonticon-classname">icon-tag</label>
      <label class="fonticon-unit">f02b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tags"></i></div>
      <label class="fonticon-classname">icon-tags</label>
      <label class="fonticon-unit">f02c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-book2"></i></div>
      <label class="fonticon-classname">icon-book2</label>
      <label class="fonticon-unit">f02d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bookmark3"></i></div>
      <label class="fonticon-classname">icon-bookmark3</label>
      <label class="fonticon-unit">f02e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-print"></i></div>
      <label class="fonticon-classname">icon-print</label>
      <label class="fonticon-unit">f02f</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-camera6"></i></div>
      <label class="fonticon-classname">icon-camera6</label>
      <label class="fonticon-unit">f030</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-font2"></i></div>
      <label class="fonticon-classname">icon-font2</label>
      <label class="fonticon-unit">f031</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bold2"></i></div>
      <label class="fonticon-classname">icon-bold2</label>
      <label class="fonticon-unit">f032</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-italic2"></i></div>
      <label class="fonticon-classname">icon-italic2</label>
      <label class="fonticon-unit">f033</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-text-height2"></i></div>
      <label class="fonticon-classname">icon-text-height2</label>
      <label class="fonticon-unit">f034</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-text-width2"></i></div>
      <label class="fonticon-classname">icon-text-width2</label>
      <label class="fonticon-unit">f035</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-align-left"></i></div>
      <label class="fonticon-classname">icon-align-left</label>
      <label class="fonticon-unit">f036</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-align-center"></i></div>
      <label class="fonticon-classname">icon-align-center</label>
      <label class="fonticon-unit">f037</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-align-right"></i></div>
      <label class="fonticon-classname">icon-align-right</label>
      <label class="fonticon-unit">f038</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-align-justify"></i></div>
      <label class="fonticon-classname">icon-align-justify</label>
      <label class="fonticon-unit">f039</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-list3"></i></div>
      <label class="fonticon-classname">icon-list3</label>
      <label class="fonticon-unit">f03a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-dedent"></i></div>
      <label class="fonticon-classname">icon-dedent</label>
      <label class="fonticon-unit">f03b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-outdent"></i></div>
      <label class="fonticon-classname">icon-outdent</label>
      <label class="fonticon-unit">f03b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-indent"></i></div>
      <label class="fonticon-classname">icon-indent</label>
      <label class="fonticon-unit">f03c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-video-camera2"></i></div>
      <label class="fonticon-classname">icon-video-camera2</label>
      <label class="fonticon-unit">f03d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-image3"></i></div>
      <label class="fonticon-classname">icon-image3</label>
      <label class="fonticon-unit">f03e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-photo"></i></div>
      <label class="fonticon-classname">icon-photo</label>
      <label class="fonticon-unit">f03e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-picture-o"></i></div>
      <label class="fonticon-classname">icon-picture-o</label>
      <label class="fonticon-unit">f03e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pencil3"></i></div>
      <label class="fonticon-classname">icon-pencil3</label>
      <label class="fonticon-unit">f040</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-map-marker"></i></div>
      <label class="fonticon-classname">icon-map-marker</label>
      <label class="fonticon-unit">f041</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-adjust"></i></div>
      <label class="fonticon-classname">icon-adjust</label>
      <label class="fonticon-unit">f042</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tint"></i></div>
      <label class="fonticon-classname">icon-tint</label>
      <label class="fonticon-unit">f043</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-edit2"></i></div>
      <label class="fonticon-classname">icon-edit2</label>
      <label class="fonticon-unit">f044</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pencil-square-o"></i></div>
      <label class="fonticon-classname">icon-pencil-square-o</label>
      <label class="fonticon-unit">f044</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-share-square-o"></i></div>
      <label class="fonticon-classname">icon-share-square-o</label>
      <label class="fonticon-unit">f045</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-check-square-o"></i></div>
      <label class="fonticon-classname">icon-check-square-o</label>
      <label class="fonticon-unit">f046</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrows"></i></div>
      <label class="fonticon-classname">icon-arrows</label>
      <label class="fonticon-unit">f047</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-step-backward"></i></div>
      <label class="fonticon-classname">icon-step-backward</label>
      <label class="fonticon-unit">f048</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fast-backward"></i></div>
      <label class="fonticon-classname">icon-fast-backward</label>
      <label class="fonticon-unit">f049</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-backward3"></i></div>
      <label class="fonticon-classname">icon-backward3</label>
      <label class="fonticon-unit">f04a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-play4"></i></div>
      <label class="fonticon-classname">icon-play4</label>
      <label class="fonticon-unit">f04b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pause3"></i></div>
      <label class="fonticon-classname">icon-pause3</label>
      <label class="fonticon-unit">f04c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stop3"></i></div>
      <label class="fonticon-classname">icon-stop3</label>
      <label class="fonticon-unit">f04d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-forward4"></i></div>
      <label class="fonticon-classname">icon-forward4</label>
      <label class="fonticon-unit">f04e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fast-forward"></i></div>
      <label class="fonticon-classname">icon-fast-forward</label>
      <label class="fonticon-unit">f050</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-step-forward"></i></div>
      <label class="fonticon-classname">icon-step-forward</label>
      <label class="fonticon-unit">f051</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-eject3"></i></div>
      <label class="fonticon-classname">icon-eject3</label>
      <label class="fonticon-unit">f052</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-left2"></i></div>
      <label class="fonticon-classname">icon-chevron-left2</label>
      <label class="fonticon-unit">f053</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-right2"></i></div>
      <label class="fonticon-classname">icon-chevron-right2</label>
      <label class="fonticon-unit">f054</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-plus-circle"></i></div>
      <label class="fonticon-classname">icon-plus-circle</label>
      <label class="fonticon-unit">f055</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-minus-circle"></i></div>
      <label class="fonticon-classname">icon-minus-circle</label>
      <label class="fonticon-unit">f056</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-times-circle"></i></div>
      <label class="fonticon-classname">icon-times-circle</label>
      <label class="fonticon-unit">f057</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-check-circle"></i></div>
      <label class="fonticon-classname">icon-check-circle</label>
      <label class="fonticon-unit">f058</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-question-circle"></i></div>
      <label class="fonticon-classname">icon-question-circle</label>
      <label class="fonticon-unit">f059</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-info-circle"></i></div>
      <label class="fonticon-classname">icon-info-circle</label>
      <label class="fonticon-unit">f05a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-crosshairs"></i></div>
      <label class="fonticon-classname">icon-crosshairs</label>
      <label class="fonticon-unit">f05b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-times-circle-o"></i></div>
      <label class="fonticon-classname">icon-times-circle-o</label>
      <label class="fonticon-unit">f05c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-check-circle-o"></i></div>
      <label class="fonticon-classname">icon-check-circle-o</label>
      <label class="fonticon-unit">f05d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ban"></i></div>
      <label class="fonticon-classname">icon-ban</label>
      <label class="fonticon-unit">f05e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-left3"></i></div>
      <label class="fonticon-classname">icon-arrow-left3</label>
      <label class="fonticon-unit">f060</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-right3"></i></div>
      <label class="fonticon-classname">icon-arrow-right3</label>
      <label class="fonticon-unit">f061</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-up3"></i></div>
      <label class="fonticon-classname">icon-arrow-up3</label>
      <label class="fonticon-unit">f062</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-down3"></i></div>
      <label class="fonticon-classname">icon-arrow-down3</label>
      <label class="fonticon-unit">f063</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mail-forward"></i></div>
      <label class="fonticon-classname">icon-mail-forward</label>
      <label class="fonticon-unit">f064</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-share3"></i></div>
      <label class="fonticon-classname">icon-share3</label>
      <label class="fonticon-unit">f064</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-expand"></i></div>
      <label class="fonticon-classname">icon-expand</label>
      <label class="fonticon-unit">f065</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-compress"></i></div>
      <label class="fonticon-classname">icon-compress</label>
      <label class="fonticon-unit">f066</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-plus3"></i></div>
      <label class="fonticon-classname">icon-plus3</label>
      <label class="fonticon-unit">f067</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-minus3"></i></div>
      <label class="fonticon-classname">icon-minus3</label>
      <label class="fonticon-unit">f068</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-asterisk2"></i></div>
      <label class="fonticon-classname">icon-asterisk2</label>
      <label class="fonticon-unit">f069</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-exclamation-circle"></i></div>
      <label class="fonticon-classname">icon-exclamation-circle</label>
      <label class="fonticon-unit">f06a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gift3"></i></div>
      <label class="fonticon-classname">icon-gift3</label>
      <label class="fonticon-unit">f06b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-leaf3"></i></div>
      <label class="fonticon-classname">icon-leaf3</label>
      <label class="fonticon-unit">f06c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fire2"></i></div>
      <label class="fonticon-classname">icon-fire2</label>
      <label class="fonticon-unit">f06d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-eye4"></i></div>
      <label class="fonticon-classname">icon-eye4</label>
      <label class="fonticon-unit">f06e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-eye-slash"></i></div>
      <label class="fonticon-classname">icon-eye-slash</label>
      <label class="fonticon-unit">f070</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-exclamation-triangle"></i></div>
      <label class="fonticon-classname">icon-exclamation-triangle</label>
      <label class="fonticon-unit">f071</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-warning2"></i></div>
      <label class="fonticon-classname">icon-warning2</label>
      <label class="fonticon-unit">f071</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-plane2"></i></div>
      <label class="fonticon-classname">icon-plane2</label>
      <label class="fonticon-unit">f072</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-calendar4"></i></div>
      <label class="fonticon-classname">icon-calendar4</label>
      <label class="fonticon-unit">f073</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-random"></i></div>
      <label class="fonticon-classname">icon-random</label>
      <label class="fonticon-unit">f074</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-comment"></i></div>
      <label class="fonticon-classname">icon-comment</label>
      <label class="fonticon-unit">f075</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-magnet3"></i></div>
      <label class="fonticon-classname">icon-magnet3</label>
      <label class="fonticon-unit">f076</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-up2"></i></div>
      <label class="fonticon-classname">icon-chevron-up2</label>
      <label class="fonticon-unit">f077</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-down2"></i></div>
      <label class="fonticon-classname">icon-chevron-down2</label>
      <label class="fonticon-unit">f078</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-retweet"></i></div>
      <label class="fonticon-classname">icon-retweet</label>
      <label class="fonticon-unit">f079</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-shopping-cart"></i></div>
      <label class="fonticon-classname">icon-shopping-cart</label>
      <label class="fonticon-unit">f07a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-folder3"></i></div>
      <label class="fonticon-classname">icon-folder3</label>
      <label class="fonticon-unit">f07b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-folder-open2"></i></div>
      <label class="fonticon-classname">icon-folder-open2</label>
      <label class="fonticon-unit">f07c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrows-v"></i></div>
      <label class="fonticon-classname">icon-arrows-v</label>
      <label class="fonticon-unit">f07d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrows-h"></i></div>
      <label class="fonticon-classname">icon-arrows-h</label>
      <label class="fonticon-unit">f07e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bar-chart"></i></div>
      <label class="fonticon-classname">icon-bar-chart</label>
      <label class="fonticon-unit">f080</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bar-chart-o"></i></div>
      <label class="fonticon-classname">icon-bar-chart-o</label>
      <label class="fonticon-unit">f080</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-twitter-square"></i></div>
      <label class="fonticon-classname">icon-twitter-square</label>
      <label class="fonticon-unit">f081</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-facebook-square"></i></div>
      <label class="fonticon-classname">icon-facebook-square</label>
      <label class="fonticon-unit">f082</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-camera-retro"></i></div>
      <label class="fonticon-classname">icon-camera-retro</label>
      <label class="fonticon-unit">f083</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-key3"></i></div>
      <label class="fonticon-classname">icon-key3</label>
      <label class="fonticon-unit">f084</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cogs2"></i></div>
      <label class="fonticon-classname">icon-cogs2</label>
      <label class="fonticon-unit">f085</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gears"></i></div>
      <label class="fonticon-classname">icon-gears</label>
      <label class="fonticon-unit">f085</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-comments"></i></div>
      <label class="fonticon-classname">icon-comments</label>
      <label class="fonticon-unit">f086</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-thumbs-o-up"></i></div>
      <label class="fonticon-classname">icon-thumbs-o-up</label>
      <label class="fonticon-unit">f087</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-thumbs-o-down"></i></div>
      <label class="fonticon-classname">icon-thumbs-o-down</label>
      <label class="fonticon-unit">f088</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-star-half2"></i></div>
      <label class="fonticon-classname">icon-star-half2</label>
      <label class="fonticon-unit">f089</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-heart-o"></i></div>
      <label class="fonticon-classname">icon-heart-o</label>
      <label class="fonticon-unit">f08a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sign-out"></i></div>
      <label class="fonticon-classname">icon-sign-out</label>
      <label class="fonticon-unit">f08b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-linkedin-square"></i></div>
      <label class="fonticon-classname">icon-linkedin-square</label>
      <label class="fonticon-unit">f08c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-thumb-tack"></i></div>
      <label class="fonticon-classname">icon-thumb-tack</label>
      <label class="fonticon-unit">f08d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-external-link"></i></div>
      <label class="fonticon-classname">icon-external-link</label>
      <label class="fonticon-unit">f08e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sign-in"></i></div>
      <label class="fonticon-classname">icon-sign-in</label>
      <label class="fonticon-unit">f090</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-trophy3"></i></div>
      <label class="fonticon-classname">icon-trophy3</label>
      <label class="fonticon-unit">f091</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-github-square"></i></div>
      <label class="fonticon-classname">icon-github-square</label>
      <label class="fonticon-unit">f092</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-upload4"></i></div>
      <label class="fonticon-classname">icon-upload4</label>
      <label class="fonticon-unit">f093</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-lemon-o"></i></div>
      <label class="fonticon-classname">icon-lemon-o</label>
      <label class="fonticon-unit">f094</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-phone2"></i></div>
      <label class="fonticon-classname">icon-phone2</label>
      <label class="fonticon-unit">f095</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-square-o"></i></div>
      <label class="fonticon-classname">icon-square-o</label>
      <label class="fonticon-unit">f096</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bookmark-o"></i></div>
      <label class="fonticon-classname">icon-bookmark-o</label>
      <label class="fonticon-unit">f097</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-phone-square"></i></div>
      <label class="fonticon-classname">icon-phone-square</label>
      <label class="fonticon-unit">f098</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-twitter3"></i></div>
      <label class="fonticon-classname">icon-twitter3</label>
      <label class="fonticon-unit">f099</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-facebook3"></i></div>
      <label class="fonticon-classname">icon-facebook3</label>
      <label class="fonticon-unit">f09a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-facebook-f"></i></div>
      <label class="fonticon-classname">icon-facebook-f</label>
      <label class="fonticon-unit">f09a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-github2"></i></div>
      <label class="fonticon-classname">icon-github2</label>
      <label class="fonticon-unit">f09b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-unlock"></i></div>
      <label class="fonticon-classname">icon-unlock</label>
      <label class="fonticon-unit">f09c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-credit-card2"></i></div>
      <label class="fonticon-classname">icon-credit-card2</label>
      <label class="fonticon-unit">f09d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-feed2"></i></div>
      <label class="fonticon-classname">icon-feed2</label>
      <label class="fonticon-unit">f09e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rss3"></i></div>
      <label class="fonticon-classname">icon-rss3</label>
      <label class="fonticon-unit">f09e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hdd-o"></i></div>
      <label class="fonticon-classname">icon-hdd-o</label>
      <label class="fonticon-unit">f0a0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bullhorn2"></i></div>
      <label class="fonticon-classname">icon-bullhorn2</label>
      <label class="fonticon-unit">f0a1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bell-o"></i></div>
      <label class="fonticon-classname">icon-bell-o</label>
      <label class="fonticon-unit">f0a2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-certificate"></i></div>
      <label class="fonticon-classname">icon-certificate</label>
      <label class="fonticon-unit">f0a3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-o-right"></i></div>
      <label class="fonticon-classname">icon-hand-o-right</label>
      <label class="fonticon-unit">f0a4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-o-left"></i></div>
      <label class="fonticon-classname">icon-hand-o-left</label>
      <label class="fonticon-unit">f0a5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-o-up"></i></div>
      <label class="fonticon-classname">icon-hand-o-up</label>
      <label class="fonticon-unit">f0a6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-o-down"></i></div>
      <label class="fonticon-classname">icon-hand-o-down</label>
      <label class="fonticon-unit">f0a7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-left"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-left</label>
      <label class="fonticon-unit">f0a8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-right"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-right</label>
      <label class="fonticon-unit">f0a9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-up"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-up</label>
      <label class="fonticon-unit">f0aa</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-down"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-down</label>
      <label class="fonticon-unit">f0ab</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-globe"></i></div>
      <label class="fonticon-classname">icon-globe</label>
      <label class="fonticon-unit">f0ac</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wrench4"></i></div>
      <label class="fonticon-classname">icon-wrench4</label>
      <label class="fonticon-unit">f0ad</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tasks"></i></div>
      <label class="fonticon-classname">icon-tasks</label>
      <label class="fonticon-unit">f0ae</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-filter2"></i></div>
      <label class="fonticon-classname">icon-filter2</label>
      <label class="fonticon-unit">f0b0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-briefcase3"></i></div>
      <label class="fonticon-classname">icon-briefcase3</label>
      <label class="fonticon-unit">f0b1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrows-alt"></i></div>
      <label class="fonticon-classname">icon-arrows-alt</label>
      <label class="fonticon-unit">f0b2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-group"></i></div>
      <label class="fonticon-classname">icon-group</label>
      <label class="fonticon-unit">f0c0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-users3"></i></div>
      <label class="fonticon-classname">icon-users3</label>
      <label class="fonticon-unit">f0c0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chain"></i></div>
      <label class="fonticon-classname">icon-chain</label>
      <label class="fonticon-unit">f0c1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-link3"></i></div>
      <label class="fonticon-classname">icon-link3</label>
      <label class="fonticon-unit">f0c1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cloud3"></i></div>
      <label class="fonticon-classname">icon-cloud3</label>
      <label class="fonticon-unit">f0c2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-flask"></i></div>
      <label class="fonticon-classname">icon-flask</label>
      <label class="fonticon-unit">f0c3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cut"></i></div>
      <label class="fonticon-classname">icon-cut</label>
      <label class="fonticon-unit">f0c4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-scissors4"></i></div>
      <label class="fonticon-classname">icon-scissors4</label>
      <label class="fonticon-unit">f0c4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-copy2"></i></div>
      <label class="fonticon-classname">icon-copy2</label>
      <label class="fonticon-unit">f0c5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-files-o"></i></div>
      <label class="fonticon-classname">icon-files-o</label>
      <label class="fonticon-unit">f0c5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paperclip2"></i></div>
      <label class="fonticon-classname">icon-paperclip2</label>
      <label class="fonticon-unit">f0c6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-floppy-o"></i></div>
      <label class="fonticon-classname">icon-floppy-o</label>
      <label class="fonticon-unit">f0c7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-save"></i></div>
      <label class="fonticon-classname">icon-save</label>
      <label class="fonticon-unit">f0c7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-square"></i></div>
      <label class="fonticon-classname">icon-square</label>
      <label class="fonticon-unit">f0c8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bars"></i></div>
      <label class="fonticon-classname">icon-bars</label>
      <label class="fonticon-unit">f0c9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-navicon2"></i></div>
      <label class="fonticon-classname">icon-navicon2</label>
      <label class="fonticon-unit">f0c9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-reorder"></i></div>
      <label class="fonticon-classname">icon-reorder</label>
      <label class="fonticon-unit">f0c9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-list-ul"></i></div>
      <label class="fonticon-classname">icon-list-ul</label>
      <label class="fonticon-unit">f0ca</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-list-ol"></i></div>
      <label class="fonticon-classname">icon-list-ol</label>
      <label class="fonticon-unit">f0cb</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-strikethrough2"></i></div>
      <label class="fonticon-classname">icon-strikethrough2</label>
      <label class="fonticon-unit">f0cc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-underline2"></i></div>
      <label class="fonticon-classname">icon-underline2</label>
      <label class="fonticon-unit">f0cd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-table3"></i></div>
      <label class="fonticon-classname">icon-table3</label>
      <label class="fonticon-unit">f0ce</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-magic"></i></div>
      <label class="fonticon-classname">icon-magic</label>
      <label class="fonticon-unit">f0d0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-truck2"></i></div>
      <label class="fonticon-classname">icon-truck2</label>
      <label class="fonticon-unit">f0d1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pinterest3"></i></div>
      <label class="fonticon-classname">icon-pinterest3</label>
      <label class="fonticon-unit">f0d2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pinterest-square"></i></div>
      <label class="fonticon-classname">icon-pinterest-square</label>
      <label class="fonticon-unit">f0d3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-google-plus-square"></i></div>
      <label class="fonticon-classname">icon-google-plus-square</label>
      <label class="fonticon-unit">f0d4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-google-plus4"></i></div>
      <label class="fonticon-classname">icon-google-plus4</label>
      <label class="fonticon-unit">f0d5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-money"></i></div>
      <label class="fonticon-classname">icon-money</label>
      <label class="fonticon-unit">f0d6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-down"></i></div>
      <label class="fonticon-classname">icon-caret-down</label>
      <label class="fonticon-unit">f0d7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-up"></i></div>
      <label class="fonticon-classname">icon-caret-up</label>
      <label class="fonticon-unit">f0d8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-left"></i></div>
      <label class="fonticon-classname">icon-caret-left</label>
      <label class="fonticon-unit">f0d9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-right"></i></div>
      <label class="fonticon-classname">icon-caret-right</label>
      <label class="fonticon-unit">f0da</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-columns"></i></div>
      <label class="fonticon-classname">icon-columns</label>
      <label class="fonticon-unit">f0db</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort"></i></div>
      <label class="fonticon-classname">icon-sort</label>
      <label class="fonticon-unit">f0dc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-unsorted"></i></div>
      <label class="fonticon-classname">icon-unsorted</label>
      <label class="fonticon-unit">f0dc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-desc"></i></div>
      <label class="fonticon-classname">icon-sort-desc</label>
      <label class="fonticon-unit">f0dd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-down"></i></div>
      <label class="fonticon-classname">icon-sort-down</label>
      <label class="fonticon-unit">f0dd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-asc"></i></div>
      <label class="fonticon-classname">icon-sort-asc</label>
      <label class="fonticon-unit">f0de</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-up"></i></div>
      <label class="fonticon-classname">icon-sort-up</label>
      <label class="fonticon-unit">f0de</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-envelope"></i></div>
      <label class="fonticon-classname">icon-envelope</label>
      <label class="fonticon-unit">f0e0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-linkedin3"></i></div>
      <label class="fonticon-classname">icon-linkedin3</label>
      <label class="fonticon-unit">f0e1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rotate-left"></i></div>
      <label class="fonticon-classname">icon-rotate-left</label>
      <label class="fonticon-unit">f0e2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-undo3"></i></div>
      <label class="fonticon-classname">icon-undo3</label>
      <label class="fonticon-unit">f0e2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gavel"></i></div>
      <label class="fonticon-classname">icon-gavel</label>
      <label class="fonticon-unit">f0e3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-legal"></i></div>
      <label class="fonticon-classname">icon-legal</label>
      <label class="fonticon-unit">f0e3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-dashboard"></i></div>
      <label class="fonticon-classname">icon-dashboard</label>
      <label class="fonticon-unit">f0e4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tachometer"></i></div>
      <label class="fonticon-classname">icon-tachometer</label>
      <label class="fonticon-unit">f0e4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-comment-o"></i></div>
      <label class="fonticon-classname">icon-comment-o</label>
      <label class="fonticon-unit">f0e5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-comments-o"></i></div>
      <label class="fonticon-classname">icon-comments-o</label>
      <label class="fonticon-unit">f0e6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bolt"></i></div>
      <label class="fonticon-classname">icon-bolt</label>
      <label class="fonticon-unit">f0e7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-flash2"></i></div>
      <label class="fonticon-classname">icon-flash2</label>
      <label class="fonticon-unit">f0e7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sitemap"></i></div>
      <label class="fonticon-classname">icon-sitemap</label>
      <label class="fonticon-unit">f0e8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-umbrella2"></i></div>
      <label class="fonticon-classname">icon-umbrella2</label>
      <label class="fonticon-unit">f0e9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-clipboard3"></i></div>
      <label class="fonticon-classname">icon-clipboard3</label>
      <label class="fonticon-unit">f0ea</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paste2"></i></div>
      <label class="fonticon-classname">icon-paste2</label>
      <label class="fonticon-unit">f0ea</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-lightbulb-o"></i></div>
      <label class="fonticon-classname">icon-lightbulb-o</label>
      <label class="fonticon-unit">f0eb</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-exchange"></i></div>
      <label class="fonticon-classname">icon-exchange</label>
      <label class="fonticon-unit">f0ec</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cloud-download2"></i></div>
      <label class="fonticon-classname">icon-cloud-download2</label>
      <label class="fonticon-unit">f0ed</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cloud-upload2"></i></div>
      <label class="fonticon-classname">icon-cloud-upload2</label>
      <label class="fonticon-unit">f0ee</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-user-md"></i></div>
      <label class="fonticon-classname">icon-user-md</label>
      <label class="fonticon-unit">f0f0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stethoscope"></i></div>
      <label class="fonticon-classname">icon-stethoscope</label>
      <label class="fonticon-unit">f0f1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-suitcase"></i></div>
      <label class="fonticon-classname">icon-suitcase</label>
      <label class="fonticon-unit">f0f2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bell3"></i></div>
      <label class="fonticon-classname">icon-bell3</label>
      <label class="fonticon-unit">f0f3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-coffee2"></i></div>
      <label class="fonticon-classname">icon-coffee2</label>
      <label class="fonticon-unit">f0f4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cutlery"></i></div>
      <label class="fonticon-classname">icon-cutlery</label>
      <label class="fonticon-unit">f0f5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-text-o"></i></div>
      <label class="fonticon-classname">icon-file-text-o</label>
      <label class="fonticon-unit">f0f6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-building-o"></i></div>
      <label class="fonticon-classname">icon-building-o</label>
      <label class="fonticon-unit">f0f7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hospital-o"></i></div>
      <label class="fonticon-classname">icon-hospital-o</label>
      <label class="fonticon-unit">f0f8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ambulance"></i></div>
      <label class="fonticon-classname">icon-ambulance</label>
      <label class="fonticon-unit">f0f9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-medkit2"></i></div>
      <label class="fonticon-classname">icon-medkit2</label>
      <label class="fonticon-unit">f0fa</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fighter-jet"></i></div>
      <label class="fonticon-classname">icon-fighter-jet</label>
      <label class="fonticon-unit">f0fb</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-beer2"></i></div>
      <label class="fonticon-classname">icon-beer2</label>
      <label class="fonticon-unit">f0fc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-h-square"></i></div>
      <label class="fonticon-classname">icon-h-square</label>
      <label class="fonticon-unit">f0fd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-plus-square"></i></div>
      <label class="fonticon-classname">icon-plus-square</label>
      <label class="fonticon-unit">f0fe</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-double-left"></i></div>
      <label class="fonticon-classname">icon-angle-double-left</label>
      <label class="fonticon-unit">f100</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-double-right"></i></div>
      <label class="fonticon-classname">icon-angle-double-right</label>
      <label class="fonticon-unit">f101</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-double-up"></i></div>
      <label class="fonticon-classname">icon-angle-double-up</label>
      <label class="fonticon-unit">f102</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-double-down"></i></div>
      <label class="fonticon-classname">icon-angle-double-down</label>
      <label class="fonticon-unit">f103</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-left"></i></div>
      <label class="fonticon-classname">icon-angle-left</label>
      <label class="fonticon-unit">f104</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-right"></i></div>
      <label class="fonticon-classname">icon-angle-right</label>
      <label class="fonticon-unit">f105</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-up"></i></div>
      <label class="fonticon-classname">icon-angle-up</label>
      <label class="fonticon-unit">f106</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angle-down"></i></div>
      <label class="fonticon-classname">icon-angle-down</label>
      <label class="fonticon-unit">f107</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-desktop"></i></div>
      <label class="fonticon-classname">icon-desktop</label>
      <label class="fonticon-unit">f108</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-laptop4"></i></div>
      <label class="fonticon-classname">icon-laptop4</label>
      <label class="fonticon-unit">f109</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tablet2"></i></div>
      <label class="fonticon-classname">icon-tablet2</label>
      <label class="fonticon-unit">f10a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mobile3"></i></div>
      <label class="fonticon-classname">icon-mobile3</label>
      <label class="fonticon-unit">f10b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mobile-phone"></i></div>
      <label class="fonticon-classname">icon-mobile-phone</label>
      <label class="fonticon-unit">f10b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-circle-o"></i></div>
      <label class="fonticon-classname">icon-circle-o</label>
      <label class="fonticon-unit">f10c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-quote-left"></i></div>
      <label class="fonticon-classname">icon-quote-left</label>
      <label class="fonticon-unit">f10d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-quote-right"></i></div>
      <label class="fonticon-classname">icon-quote-right</label>
      <label class="fonticon-unit">f10e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-spinner12"></i></div>
      <label class="fonticon-classname">icon-spinner12</label>
      <label class="fonticon-unit">f110</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-circle"></i></div>
      <label class="fonticon-classname">icon-circle</label>
      <label class="fonticon-unit">f111</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mail-reply"></i></div>
      <label class="fonticon-classname">icon-mail-reply</label>
      <label class="fonticon-unit">f112</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-reply3"></i></div>
      <label class="fonticon-classname">icon-reply3</label>
      <label class="fonticon-unit">f112</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-github-alt"></i></div>
      <label class="fonticon-classname">icon-github-alt</label>
      <label class="fonticon-unit">f113</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-folder-o"></i></div>
      <label class="fonticon-classname">icon-folder-o</label>
      <label class="fonticon-unit">f114</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-folder-open-o"></i></div>
      <label class="fonticon-classname">icon-folder-open-o</label>
      <label class="fonticon-unit">f115</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-smile-o"></i></div>
      <label class="fonticon-classname">icon-smile-o</label>
      <label class="fonticon-unit">f118</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-frown-o"></i></div>
      <label class="fonticon-classname">icon-frown-o</label>
      <label class="fonticon-unit">f119</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-meh-o"></i></div>
      <label class="fonticon-classname">icon-meh-o</label>
      <label class="fonticon-unit">f11a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gamepad2"></i></div>
      <label class="fonticon-classname">icon-gamepad2</label>
      <label class="fonticon-unit">f11b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-keyboard-o"></i></div>
      <label class="fonticon-classname">icon-keyboard-o</label>
      <label class="fonticon-unit">f11c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-flag-o"></i></div>
      <label class="fonticon-classname">icon-flag-o</label>
      <label class="fonticon-unit">f11d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-flag-checkered"></i></div>
      <label class="fonticon-classname">icon-flag-checkered</label>
      <label class="fonticon-unit">f11e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-terminal2"></i></div>
      <label class="fonticon-classname">icon-terminal2</label>
      <label class="fonticon-unit">f120</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-code2"></i></div>
      <label class="fonticon-classname">icon-code2</label>
      <label class="fonticon-unit">f121</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mail-reply-all"></i></div>
      <label class="fonticon-classname">icon-mail-reply-all</label>
      <label class="fonticon-unit">f122</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-reply-all2"></i></div>
      <label class="fonticon-classname">icon-reply-all2</label>
      <label class="fonticon-unit">f122</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-star-half-empty"></i></div>
      <label class="fonticon-classname">icon-star-half-empty</label>
      <label class="fonticon-unit">f123</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-star-half-full"></i></div>
      <label class="fonticon-classname">icon-star-half-full</label>
      <label class="fonticon-unit">f123</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-star-half-o"></i></div>
      <label class="fonticon-classname">icon-star-half-o</label>
      <label class="fonticon-unit">f123</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-location-arrow"></i></div>
      <label class="fonticon-classname">icon-location-arrow</label>
      <label class="fonticon-unit">f124</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-crop3"></i></div>
      <label class="fonticon-classname">icon-crop3</label>
      <label class="fonticon-unit">f125</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-code-fork"></i></div>
      <label class="fonticon-classname">icon-code-fork</label>
      <label class="fonticon-unit">f126</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chain-broken"></i></div>
      <label class="fonticon-classname">icon-chain-broken</label>
      <label class="fonticon-unit">f127</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-unlink"></i></div>
      <label class="fonticon-classname">icon-unlink</label>
      <label class="fonticon-unit">f127</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-question2"></i></div>
      <label class="fonticon-classname">icon-question2</label>
      <label class="fonticon-unit">f128</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-info2"></i></div>
      <label class="fonticon-classname">icon-info2</label>
      <label class="fonticon-unit">f129</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-exclamation"></i></div>
      <label class="fonticon-classname">icon-exclamation</label>
      <label class="fonticon-unit">f12a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-superscript3"></i></div>
      <label class="fonticon-classname">icon-superscript3</label>
      <label class="fonticon-unit">f12b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-subscript3"></i></div>
      <label class="fonticon-classname">icon-subscript3</label>
      <label class="fonticon-unit">f12c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-eraser"></i></div>
      <label class="fonticon-classname">icon-eraser</label>
      <label class="fonticon-unit">f12d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-puzzle-piece"></i></div>
      <label class="fonticon-classname">icon-puzzle-piece</label>
      <label class="fonticon-unit">f12e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-microphone"></i></div>
      <label class="fonticon-classname">icon-microphone</label>
      <label class="fonticon-unit">f130</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-microphone-slash"></i></div>
      <label class="fonticon-classname">icon-microphone-slash</label>
      <label class="fonticon-unit">f131</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-shield2"></i></div>
      <label class="fonticon-classname">icon-shield2</label>
      <label class="fonticon-unit">f132</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-calendar-o"></i></div>
      <label class="fonticon-classname">icon-calendar-o</label>
      <label class="fonticon-unit">f133</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fire-extinguisher"></i></div>
      <label class="fonticon-classname">icon-fire-extinguisher</label>
      <label class="fonticon-unit">f134</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rocket2"></i></div>
      <label class="fonticon-classname">icon-rocket2</label>
      <label class="fonticon-unit">f135</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-maxcdn"></i></div>
      <label class="fonticon-classname">icon-maxcdn</label>
      <label class="fonticon-unit">f136</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-circle-left"></i></div>
      <label class="fonticon-classname">icon-chevron-circle-left</label>
      <label class="fonticon-unit">f137</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-circle-right"></i></div>
      <label class="fonticon-classname">icon-chevron-circle-right</label>
      <label class="fonticon-unit">f138</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-circle-up"></i></div>
      <label class="fonticon-classname">icon-chevron-circle-up</label>
      <label class="fonticon-unit">f139</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chevron-circle-down"></i></div>
      <label class="fonticon-classname">icon-chevron-circle-down</label>
      <label class="fonticon-unit">f13a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-html5"></i></div>
      <label class="fonticon-classname">icon-html5</label>
      <label class="fonticon-unit">f13b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-css32"></i></div>
      <label class="fonticon-classname">icon-css32</label>
      <label class="fonticon-unit">f13c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-anchor"></i></div>
      <label class="fonticon-classname">icon-anchor</label>
      <label class="fonticon-unit">f13d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-unlock-alt"></i></div>
      <label class="fonticon-classname">icon-unlock-alt</label>
      <label class="fonticon-unit">f13e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bullseye"></i></div>
      <label class="fonticon-classname">icon-bullseye</label>
      <label class="fonticon-unit">f140</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ellipsis-h"></i></div>
      <label class="fonticon-classname">icon-ellipsis-h</label>
      <label class="fonticon-unit">f141</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ellipsis-v"></i></div>
      <label class="fonticon-classname">icon-ellipsis-v</label>
      <label class="fonticon-unit">f142</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rss-square"></i></div>
      <label class="fonticon-classname">icon-rss-square</label>
      <label class="fonticon-unit">f143</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-play-circle"></i></div>
      <label class="fonticon-classname">icon-play-circle</label>
      <label class="fonticon-unit">f144</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ticket2"></i></div>
      <label class="fonticon-classname">icon-ticket2</label>
      <label class="fonticon-unit">f145</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-minus-square"></i></div>
      <label class="fonticon-classname">icon-minus-square</label>
      <label class="fonticon-unit">f146</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-minus-square-o"></i></div>
      <label class="fonticon-classname">icon-minus-square-o</label>
      <label class="fonticon-unit">f147</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-level-up"></i></div>
      <label class="fonticon-classname">icon-level-up</label>
      <label class="fonticon-unit">f148</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-level-down"></i></div>
      <label class="fonticon-classname">icon-level-down</label>
      <label class="fonticon-unit">f149</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-check-square"></i></div>
      <label class="fonticon-classname">icon-check-square</label>
      <label class="fonticon-unit">f14a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pencil-square"></i></div>
      <label class="fonticon-classname">icon-pencil-square</label>
      <label class="fonticon-unit">f14b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-external-link-square"></i></div>
      <label class="fonticon-classname">icon-external-link-square</label>
      <label class="fonticon-unit">f14c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-share-square"></i></div>
      <label class="fonticon-classname">icon-share-square</label>
      <label class="fonticon-unit">f14d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-compass3"></i></div>
      <label class="fonticon-classname">icon-compass3</label>
      <label class="fonticon-unit">f14e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-square-o-down"></i></div>
      <label class="fonticon-classname">icon-caret-square-o-down</label>
      <label class="fonticon-unit">f150</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-toggle-down"></i></div>
      <label class="fonticon-classname">icon-toggle-down</label>
      <label class="fonticon-unit">f150</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-square-o-up"></i></div>
      <label class="fonticon-classname">icon-caret-square-o-up</label>
      <label class="fonticon-unit">f151</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-toggle-up"></i></div>
      <label class="fonticon-classname">icon-toggle-up</label>
      <label class="fonticon-unit">f151</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-square-o-right"></i></div>
      <label class="fonticon-classname">icon-caret-square-o-right</label>
      <label class="fonticon-unit">f152</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-toggle-right"></i></div>
      <label class="fonticon-classname">icon-toggle-right</label>
      <label class="fonticon-unit">f152</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-eur"></i></div>
      <label class="fonticon-classname">icon-eur</label>
      <label class="fonticon-unit">f153</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-euro"></i></div>
      <label class="fonticon-classname">icon-euro</label>
      <label class="fonticon-unit">f153</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gbp"></i></div>
      <label class="fonticon-classname">icon-gbp</label>
      <label class="fonticon-unit">f154</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-dollar"></i></div>
      <label class="fonticon-classname">icon-dollar</label>
      <label class="fonticon-unit">f155</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-usd"></i></div>
      <label class="fonticon-classname">icon-usd</label>
      <label class="fonticon-unit">f155</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-inr"></i></div>
      <label class="fonticon-classname">icon-inr</label>
      <label class="fonticon-unit">f156</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rupee"></i></div>
      <label class="fonticon-classname">icon-rupee</label>
      <label class="fonticon-unit">f156</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cny"></i></div>
      <label class="fonticon-classname">icon-cny</label>
      <label class="fonticon-unit">f157</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-jpy"></i></div>
      <label class="fonticon-classname">icon-jpy</label>
      <label class="fonticon-unit">f157</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rmb"></i></div>
      <label class="fonticon-classname">icon-rmb</label>
      <label class="fonticon-unit">f157</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-yen"></i></div>
      <label class="fonticon-classname">icon-yen</label>
      <label class="fonticon-unit">f157</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rouble"></i></div>
      <label class="fonticon-classname">icon-rouble</label>
      <label class="fonticon-unit">f158</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rub"></i></div>
      <label class="fonticon-classname">icon-rub</label>
      <label class="fonticon-unit">f158</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ruble"></i></div>
      <label class="fonticon-classname">icon-ruble</label>
      <label class="fonticon-unit">f158</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-krw"></i></div>
      <label class="fonticon-classname">icon-krw</label>
      <label class="fonticon-unit">f159</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-won"></i></div>
      <label class="fonticon-classname">icon-won</label>
      <label class="fonticon-unit">f159</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bitcoin"></i></div>
      <label class="fonticon-classname">icon-bitcoin</label>
      <label class="fonticon-unit">f15a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-btc"></i></div>
      <label class="fonticon-classname">icon-btc</label>
      <label class="fonticon-unit">f15a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file"></i></div>
      <label class="fonticon-classname">icon-file</label>
      <label class="fonticon-unit">f15b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-text3"></i></div>
      <label class="fonticon-classname">icon-file-text3</label>
      <label class="fonticon-unit">f15c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-alpha-asc2"></i></div>
      <label class="fonticon-classname">icon-sort-alpha-asc2</label>
      <label class="fonticon-unit">f15d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-alpha-desc2"></i></div>
      <label class="fonticon-classname">icon-sort-alpha-desc2</label>
      <label class="fonticon-unit">f15e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-amount-asc2"></i></div>
      <label class="fonticon-classname">icon-sort-amount-asc2</label>
      <label class="fonticon-unit">f160</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-amount-desc2"></i></div>
      <label class="fonticon-classname">icon-sort-amount-desc2</label>
      <label class="fonticon-unit">f161</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-numeric-asc2"></i></div>
      <label class="fonticon-classname">icon-sort-numeric-asc2</label>
      <label class="fonticon-unit">f162</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sort-numeric-desc"></i></div>
      <label class="fonticon-classname">icon-sort-numeric-desc</label>
      <label class="fonticon-unit">f163</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-thumbs-up"></i></div>
      <label class="fonticon-classname">icon-thumbs-up</label>
      <label class="fonticon-unit">f164</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-thumbs-down"></i></div>
      <label class="fonticon-classname">icon-thumbs-down</label>
      <label class="fonticon-unit">f165</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-youtube-square"></i></div>
      <label class="fonticon-classname">icon-youtube-square</label>
      <label class="fonticon-unit">f166</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-youtube3"></i></div>
      <label class="fonticon-classname">icon-youtube3</label>
      <label class="fonticon-unit">f167</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-xing3"></i></div>
      <label class="fonticon-classname">icon-xing3</label>
      <label class="fonticon-unit">f168</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-xing-square"></i></div>
      <label class="fonticon-classname">icon-xing-square</label>
      <label class="fonticon-unit">f169</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-youtube-play"></i></div>
      <label class="fonticon-classname">icon-youtube-play</label>
      <label class="fonticon-unit">f16a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-dropbox2"></i></div>
      <label class="fonticon-classname">icon-dropbox2</label>
      <label class="fonticon-unit">f16b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stack-overflow"></i></div>
      <label class="fonticon-classname">icon-stack-overflow</label>
      <label class="fonticon-unit">f16c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-instagram2"></i></div>
      <label class="fonticon-classname">icon-instagram2</label>
      <label class="fonticon-unit">f16d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-flickr5"></i></div>
      <label class="fonticon-classname">icon-flickr5</label>
      <label class="fonticon-unit">f16e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-adn"></i></div>
      <label class="fonticon-classname">icon-adn</label>
      <label class="fonticon-unit">f170</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bitbucket"></i></div>
      <label class="fonticon-classname">icon-bitbucket</label>
      <label class="fonticon-unit">f171</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bitbucket-square"></i></div>
      <label class="fonticon-classname">icon-bitbucket-square</label>
      <label class="fonticon-unit">f172</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tumblr3"></i></div>
      <label class="fonticon-classname">icon-tumblr3</label>
      <label class="fonticon-unit">f173</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tumblr-square"></i></div>
      <label class="fonticon-classname">icon-tumblr-square</label>
      <label class="fonticon-unit">f174</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-long-arrow-down"></i></div>
      <label class="fonticon-classname">icon-long-arrow-down</label>
      <label class="fonticon-unit">f175</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-long-arrow-up"></i></div>
      <label class="fonticon-classname">icon-long-arrow-up</label>
      <label class="fonticon-unit">f176</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-long-arrow-left"></i></div>
      <label class="fonticon-classname">icon-long-arrow-left</label>
      <label class="fonticon-unit">f177</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-long-arrow-right"></i></div>
      <label class="fonticon-classname">icon-long-arrow-right</label>
      <label class="fonticon-unit">f178</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-apple"></i></div>
      <label class="fonticon-classname">icon-apple</label>
      <label class="fonticon-unit">f179</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-windows2"></i></div>
      <label class="fonticon-classname">icon-windows2</label>
      <label class="fonticon-unit">f17a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-android2"></i></div>
      <label class="fonticon-classname">icon-android2</label>
      <label class="fonticon-unit">f17b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-linux"></i></div>
      <label class="fonticon-classname">icon-linux</label>
      <label class="fonticon-unit">f17c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-dribbble3"></i></div>
      <label class="fonticon-classname">icon-dribbble3</label>
      <label class="fonticon-unit">f17d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-skype3"></i></div>
      <label class="fonticon-classname">icon-skype3</label>
      <label class="fonticon-unit">f17e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-foursquare2"></i></div>
      <label class="fonticon-classname">icon-foursquare2</label>
      <label class="fonticon-unit">f180</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-trello2"></i></div>
      <label class="fonticon-classname">icon-trello2</label>
      <label class="fonticon-unit">f181</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-female2"></i></div>
      <label class="fonticon-classname">icon-female2</label>
      <label class="fonticon-unit">f182</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-male2"></i></div>
      <label class="fonticon-classname">icon-male2</label>
      <label class="fonticon-unit">f183</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gittip"></i></div>
      <label class="fonticon-classname">icon-gittip</label>
      <label class="fonticon-unit">f184</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gratipay"></i></div>
      <label class="fonticon-classname">icon-gratipay</label>
      <label class="fonticon-unit">f184</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sun-o"></i></div>
      <label class="fonticon-classname">icon-sun-o</label>
      <label class="fonticon-unit">f185</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-moon-o"></i></div>
      <label class="fonticon-classname">icon-moon-o</label>
      <label class="fonticon-unit">f186</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-archive2"></i></div>
      <label class="fonticon-classname">icon-archive2</label>
      <label class="fonticon-unit">f187</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bug3"></i></div>
      <label class="fonticon-classname">icon-bug3</label>
      <label class="fonticon-unit">f188</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-vk2"></i></div>
      <label class="fonticon-classname">icon-vk2</label>
      <label class="fonticon-unit">f189</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-weibo"></i></div>
      <label class="fonticon-classname">icon-weibo</label>
      <label class="fonticon-unit">f18a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-renren2"></i></div>
      <label class="fonticon-classname">icon-renren2</label>
      <label class="fonticon-unit">f18b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pagelines"></i></div>
      <label class="fonticon-classname">icon-pagelines</label>
      <label class="fonticon-unit">f18c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stack-exchange"></i></div>
      <label class="fonticon-classname">icon-stack-exchange</label>
      <label class="fonticon-unit">f18d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-o-right"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-o-right</label>
      <label class="fonticon-unit">f18e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-arrow-circle-o-left"></i></div>
      <label class="fonticon-classname">icon-arrow-circle-o-left</label>
      <label class="fonticon-unit">f190</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-caret-square-o-left"></i></div>
      <label class="fonticon-classname">icon-caret-square-o-left</label>
      <label class="fonticon-unit">f191</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-toggle-left"></i></div>
      <label class="fonticon-classname">icon-toggle-left</label>
      <label class="fonticon-unit">f191</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-dot-circle-o"></i></div>
      <label class="fonticon-classname">icon-dot-circle-o</label>
      <label class="fonticon-unit">f192</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wheelchair"></i></div>
      <label class="fonticon-classname">icon-wheelchair</label>
      <label class="fonticon-unit">f193</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-vimeo-square"></i></div>
      <label class="fonticon-classname">icon-vimeo-square</label>
      <label class="fonticon-unit">f194</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-try"></i></div>
      <label class="fonticon-classname">icon-try</label>
      <label class="fonticon-unit">f195</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-turkish-lira"></i></div>
      <label class="fonticon-classname">icon-turkish-lira</label>
      <label class="fonticon-unit">f195</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-plus-square-o"></i></div>
      <label class="fonticon-classname">icon-plus-square-o</label>
      <label class="fonticon-unit">f196</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-space-shuttle"></i></div>
      <label class="fonticon-classname">icon-space-shuttle</label>
      <label class="fonticon-unit">f197</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-slack"></i></div>
      <label class="fonticon-classname">icon-slack</label>
      <label class="fonticon-unit">f198</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-envelope-square"></i></div>
      <label class="fonticon-classname">icon-envelope-square</label>
      <label class="fonticon-unit">f199</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wordpress2"></i></div>
      <label class="fonticon-classname">icon-wordpress2</label>
      <label class="fonticon-unit">f19a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-openid"></i></div>
      <label class="fonticon-classname">icon-openid</label>
      <label class="fonticon-unit">f19b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bank"></i></div>
      <label class="fonticon-classname">icon-bank</label>
      <label class="fonticon-unit">f19c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-institution"></i></div>
      <label class="fonticon-classname">icon-institution</label>
      <label class="fonticon-unit">f19c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-university2"></i></div>
      <label class="fonticon-classname">icon-university2</label>
      <label class="fonticon-unit">f19c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-graduation-cap"></i></div>
      <label class="fonticon-classname">icon-graduation-cap</label>
      <label class="fonticon-unit">f19d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mortar-board"></i></div>
      <label class="fonticon-classname">icon-mortar-board</label>
      <label class="fonticon-unit">f19d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-yahoo3"></i></div>
      <label class="fonticon-classname">icon-yahoo3</label>
      <label class="fonticon-unit">f19e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-google4"></i></div>
      <label class="fonticon-classname">icon-google4</label>
      <label class="fonticon-unit">f1a0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-reddit2"></i></div>
      <label class="fonticon-classname">icon-reddit2</label>
      <label class="fonticon-unit">f1a1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-reddit-square"></i></div>
      <label class="fonticon-classname">icon-reddit-square</label>
      <label class="fonticon-unit">f1a2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stumbleupon-circle"></i></div>
      <label class="fonticon-classname">icon-stumbleupon-circle</label>
      <label class="fonticon-unit">f1a3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stumbleupon3"></i></div>
      <label class="fonticon-classname">icon-stumbleupon3</label>
      <label class="fonticon-unit">f1a4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-delicious2"></i></div>
      <label class="fonticon-classname">icon-delicious2</label>
      <label class="fonticon-unit">f1a5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-digg2"></i></div>
      <label class="fonticon-classname">icon-digg2</label>
      <label class="fonticon-unit">f1a6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pied-piper-pp"></i></div>
      <label class="fonticon-classname">icon-pied-piper-pp</label>
      <label class="fonticon-unit">f1a7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pied-piper-alt"></i></div>
      <label class="fonticon-classname">icon-pied-piper-alt</label>
      <label class="fonticon-unit">f1a8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-drupal"></i></div>
      <label class="fonticon-classname">icon-drupal</label>
      <label class="fonticon-unit">f1a9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-joomla2"></i></div>
      <label class="fonticon-classname">icon-joomla2</label>
      <label class="fonticon-unit">f1aa</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-language"></i></div>
      <label class="fonticon-classname">icon-language</label>
      <label class="fonticon-unit">f1ab</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fax"></i></div>
      <label class="fonticon-classname">icon-fax</label>
      <label class="fonticon-unit">f1ac</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-building"></i></div>
      <label class="fonticon-classname">icon-building</label>
      <label class="fonticon-unit">f1ad</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-child"></i></div>
      <label class="fonticon-classname">icon-child</label>
      <label class="fonticon-unit">f1ae</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paw"></i></div>
      <label class="fonticon-classname">icon-paw</label>
      <label class="fonticon-unit">f1b0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-spoon2"></i></div>
      <label class="fonticon-classname">icon-spoon2</label>
      <label class="fonticon-unit">f1b1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cube2"></i></div>
      <label class="fonticon-classname">icon-cube2</label>
      <label class="fonticon-unit">f1b2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cubes"></i></div>
      <label class="fonticon-classname">icon-cubes</label>
      <label class="fonticon-unit">f1b3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-behance3"></i></div>
      <label class="fonticon-classname">icon-behance3</label>
      <label class="fonticon-unit">f1b4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-behance-square"></i></div>
      <label class="fonticon-classname">icon-behance-square</label>
      <label class="fonticon-unit">f1b5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-steam3"></i></div>
      <label class="fonticon-classname">icon-steam3</label>
      <label class="fonticon-unit">f1b6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-steam-square"></i></div>
      <label class="fonticon-classname">icon-steam-square</label>
      <label class="fonticon-unit">f1b7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-recycle"></i></div>
      <label class="fonticon-classname">icon-recycle</label>
      <label class="fonticon-unit">f1b8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-automobile"></i></div>
      <label class="fonticon-classname">icon-automobile</label>
      <label class="fonticon-unit">f1b9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-car"></i></div>
      <label class="fonticon-classname">icon-car</label>
      <label class="fonticon-unit">f1b9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cab"></i></div>
      <label class="fonticon-classname">icon-cab</label>
      <label class="fonticon-unit">f1ba</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-taxi"></i></div>
      <label class="fonticon-classname">icon-taxi</label>
      <label class="fonticon-unit">f1ba</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tree2"></i></div>
      <label class="fonticon-classname">icon-tree2</label>
      <label class="fonticon-unit">f1bb</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-spotify2"></i></div>
      <label class="fonticon-classname">icon-spotify2</label>
      <label class="fonticon-unit">f1bc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-deviantart3"></i></div>
      <label class="fonticon-classname">icon-deviantart3</label>
      <label class="fonticon-unit">f1bd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-soundcloud3"></i></div>
      <label class="fonticon-classname">icon-soundcloud3</label>
      <label class="fonticon-unit">f1be</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-database2"></i></div>
      <label class="fonticon-classname">icon-database2</label>
      <label class="fonticon-unit">f1c0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-pdf-o"></i></div>
      <label class="fonticon-classname">icon-file-pdf-o</label>
      <label class="fonticon-unit">f1c1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-word-o"></i></div>
      <label class="fonticon-classname">icon-file-word-o</label>
      <label class="fonticon-unit">f1c2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-excel-o"></i></div>
      <label class="fonticon-classname">icon-file-excel-o</label>
      <label class="fonticon-unit">f1c3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-powerpoint-o"></i></div>
      <label class="fonticon-classname">icon-file-powerpoint-o</label>
      <label class="fonticon-unit">f1c4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-image-o"></i></div>
      <label class="fonticon-classname">icon-file-image-o</label>
      <label class="fonticon-unit">f1c5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-photo-o"></i></div>
      <label class="fonticon-classname">icon-file-photo-o</label>
      <label class="fonticon-unit">f1c5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-picture-o"></i></div>
      <label class="fonticon-classname">icon-file-picture-o</label>
      <label class="fonticon-unit">f1c5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-archive-o"></i></div>
      <label class="fonticon-classname">icon-file-archive-o</label>
      <label class="fonticon-unit">f1c6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-zip-o"></i></div>
      <label class="fonticon-classname">icon-file-zip-o</label>
      <label class="fonticon-unit">f1c6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-audio-o"></i></div>
      <label class="fonticon-classname">icon-file-audio-o</label>
      <label class="fonticon-unit">f1c7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-sound-o"></i></div>
      <label class="fonticon-classname">icon-file-sound-o</label>
      <label class="fonticon-unit">f1c7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-movie-o"></i></div>
      <label class="fonticon-classname">icon-file-movie-o</label>
      <label class="fonticon-unit">f1c8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-video-o"></i></div>
      <label class="fonticon-classname">icon-file-video-o</label>
      <label class="fonticon-unit">f1c8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-file-code-o"></i></div>
      <label class="fonticon-classname">icon-file-code-o</label>
      <label class="fonticon-unit">f1c9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-vine2"></i></div>
      <label class="fonticon-classname">icon-vine2</label>
      <label class="fonticon-unit">f1ca</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-codepen2"></i></div>
      <label class="fonticon-classname">icon-codepen2</label>
      <label class="fonticon-unit">f1cb</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-jsfiddle"></i></div>
      <label class="fonticon-classname">icon-jsfiddle</label>
      <label class="fonticon-unit">f1cc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-life-bouy"></i></div>
      <label class="fonticon-classname">icon-life-bouy</label>
      <label class="fonticon-unit">f1cd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-life-buoy"></i></div>
      <label class="fonticon-classname">icon-life-buoy</label>
      <label class="fonticon-unit">f1cd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-life-ring"></i></div>
      <label class="fonticon-classname">icon-life-ring</label>
      <label class="fonticon-unit">f1cd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-life-saver"></i></div>
      <label class="fonticon-classname">icon-life-saver</label>
      <label class="fonticon-unit">f1cd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-support"></i></div>
      <label class="fonticon-classname">icon-support</label>
      <label class="fonticon-unit">f1cd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-circle-o-notch"></i></div>
      <label class="fonticon-classname">icon-circle-o-notch</label>
      <label class="fonticon-unit">f1ce</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ra"></i></div>
      <label class="fonticon-classname">icon-ra</label>
      <label class="fonticon-unit">f1d0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-rebel"></i></div>
      <label class="fonticon-classname">icon-rebel</label>
      <label class="fonticon-unit">f1d0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-resistance"></i></div>
      <label class="fonticon-classname">icon-resistance</label>
      <label class="fonticon-unit">f1d0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-empire"></i></div>
      <label class="fonticon-classname">icon-empire</label>
      <label class="fonticon-unit">f1d1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ge"></i></div>
      <label class="fonticon-classname">icon-ge</label>
      <label class="fonticon-unit">f1d1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-git-square"></i></div>
      <label class="fonticon-classname">icon-git-square</label>
      <label class="fonticon-unit">f1d2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-git2"></i></div>
      <label class="fonticon-classname">icon-git2</label>
      <label class="fonticon-unit">f1d3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hacker-news"></i></div>
      <label class="fonticon-classname">icon-hacker-news</label>
      <label class="fonticon-unit">f1d4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-y-combinator-square"></i></div>
      <label class="fonticon-classname">icon-y-combinator-square</label>
      <label class="fonticon-unit">f1d4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-yc-square"></i></div>
      <label class="fonticon-classname">icon-yc-square</label>
      <label class="fonticon-unit">f1d4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tencent-weibo"></i></div>
      <label class="fonticon-classname">icon-tencent-weibo</label>
      <label class="fonticon-unit">f1d5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-qq"></i></div>
      <label class="fonticon-classname">icon-qq</label>
      <label class="fonticon-unit">f1d6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wechat"></i></div>
      <label class="fonticon-classname">icon-wechat</label>
      <label class="fonticon-unit">f1d7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-weixin"></i></div>
      <label class="fonticon-classname">icon-weixin</label>
      <label class="fonticon-unit">f1d7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paper-plane"></i></div>
      <label class="fonticon-classname">icon-paper-plane</label>
      <label class="fonticon-unit">f1d8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-send"></i></div>
      <label class="fonticon-classname">icon-send</label>
      <label class="fonticon-unit">f1d8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paper-plane-o"></i></div>
      <label class="fonticon-classname">icon-paper-plane-o</label>
      <label class="fonticon-unit">f1d9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-send-o"></i></div>
      <label class="fonticon-classname">icon-send-o</label>
      <label class="fonticon-unit">f1d9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-history2"></i></div>
      <label class="fonticon-classname">icon-history2</label>
      <label class="fonticon-unit">f1da</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-circle-thin"></i></div>
      <label class="fonticon-classname">icon-circle-thin</label>
      <label class="fonticon-unit">f1db</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-header"></i></div>
      <label class="fonticon-classname">icon-header</label>
      <label class="fonticon-unit">f1dc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paragraph"></i></div>
      <label class="fonticon-classname">icon-paragraph</label>
      <label class="fonticon-unit">f1dd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sliders"></i></div>
      <label class="fonticon-classname">icon-sliders</label>
      <label class="fonticon-unit">f1de</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-share-alt"></i></div>
      <label class="fonticon-classname">icon-share-alt</label>
      <label class="fonticon-unit">f1e0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-share-alt-square"></i></div>
      <label class="fonticon-classname">icon-share-alt-square</label>
      <label class="fonticon-unit">f1e1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bomb"></i></div>
      <label class="fonticon-classname">icon-bomb</label>
      <label class="fonticon-unit">f1e2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-futbol-o"></i></div>
      <label class="fonticon-classname">icon-futbol-o</label>
      <label class="fonticon-unit">f1e3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-soccer-ball-o"></i></div>
      <label class="fonticon-classname">icon-soccer-ball-o</label>
      <label class="fonticon-unit">f1e3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tty"></i></div>
      <label class="fonticon-classname">icon-tty</label>
      <label class="fonticon-unit">f1e4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-binoculars2"></i></div>
      <label class="fonticon-classname">icon-binoculars2</label>
      <label class="fonticon-unit">f1e5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-plug"></i></div>
      <label class="fonticon-classname">icon-plug</label>
      <label class="fonticon-unit">f1e6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-slideshare"></i></div>
      <label class="fonticon-classname">icon-slideshare</label>
      <label class="fonticon-unit">f1e7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-twitch2"></i></div>
      <label class="fonticon-classname">icon-twitch2</label>
      <label class="fonticon-unit">f1e8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-yelp2"></i></div>
      <label class="fonticon-classname">icon-yelp2</label>
      <label class="fonticon-unit">f1e9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-newspaper-o"></i></div>
      <label class="fonticon-classname">icon-newspaper-o</label>
      <label class="fonticon-unit">f1ea</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wifi2"></i></div>
      <label class="fonticon-classname">icon-wifi2</label>
      <label class="fonticon-unit">f1eb</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-calculator4"></i></div>
      <label class="fonticon-classname">icon-calculator4</label>
      <label class="fonticon-unit">f1ec</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paypal2"></i></div>
      <label class="fonticon-classname">icon-paypal2</label>
      <label class="fonticon-unit">f1ed</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-google-wallet"></i></div>
      <label class="fonticon-classname">icon-google-wallet</label>
      <label class="fonticon-unit">f1ee</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-visa"></i></div>
      <label class="fonticon-classname">icon-cc-visa</label>
      <label class="fonticon-unit">f1f0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-mastercard"></i></div>
      <label class="fonticon-classname">icon-cc-mastercard</label>
      <label class="fonticon-unit">f1f1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-discover"></i></div>
      <label class="fonticon-classname">icon-cc-discover</label>
      <label class="fonticon-unit">f1f2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-amex"></i></div>
      <label class="fonticon-classname">icon-cc-amex</label>
      <label class="fonticon-unit">f1f3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-paypal"></i></div>
      <label class="fonticon-classname">icon-cc-paypal</label>
      <label class="fonticon-unit">f1f4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-stripe"></i></div>
      <label class="fonticon-classname">icon-cc-stripe</label>
      <label class="fonticon-unit">f1f5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bell-slash"></i></div>
      <label class="fonticon-classname">icon-bell-slash</label>
      <label class="fonticon-unit">f1f6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bell-slash-o"></i></div>
      <label class="fonticon-classname">icon-bell-slash-o</label>
      <label class="fonticon-unit">f1f7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-trash2"></i></div>
      <label class="fonticon-classname">icon-trash2</label>
      <label class="fonticon-unit">f1f8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-copyright"></i></div>
      <label class="fonticon-classname">icon-copyright</label>
      <label class="fonticon-unit">f1f9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-at2"></i></div>
      <label class="fonticon-classname">icon-at2</label>
      <label class="fonticon-unit">f1fa</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-eyedropper2"></i></div>
      <label class="fonticon-classname">icon-eyedropper2</label>
      <label class="fonticon-unit">f1fb</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-paint-brush"></i></div>
      <label class="fonticon-classname">icon-paint-brush</label>
      <label class="fonticon-unit">f1fc</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-birthday-cake"></i></div>
      <label class="fonticon-classname">icon-birthday-cake</label>
      <label class="fonticon-unit">f1fd</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-area-chart"></i></div>
      <label class="fonticon-classname">icon-area-chart</label>
      <label class="fonticon-unit">f1fe</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pie-chart2"></i></div>
      <label class="fonticon-classname">icon-pie-chart2</label>
      <label class="fonticon-unit">f200</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-line-chart"></i></div>
      <label class="fonticon-classname">icon-line-chart</label>
      <label class="fonticon-unit">f201</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-lastfm3"></i></div>
      <label class="fonticon-classname">icon-lastfm3</label>
      <label class="fonticon-unit">f202</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-lastfm-square"></i></div>
      <label class="fonticon-classname">icon-lastfm-square</label>
      <label class="fonticon-unit">f203</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-toggle-off"></i></div>
      <label class="fonticon-classname">icon-toggle-off</label>
      <label class="fonticon-unit">f204</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-toggle-on"></i></div>
      <label class="fonticon-classname">icon-toggle-on</label>
      <label class="fonticon-unit">f205</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bicycle"></i></div>
      <label class="fonticon-classname">icon-bicycle</label>
      <label class="fonticon-unit">f206</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bus"></i></div>
      <label class="fonticon-classname">icon-bus</label>
      <label class="fonticon-unit">f207</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ioxhost"></i></div>
      <label class="fonticon-classname">icon-ioxhost</label>
      <label class="fonticon-unit">f208</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-angellist"></i></div>
      <label class="fonticon-classname">icon-angellist</label>
      <label class="fonticon-unit">f209</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc"></i></div>
      <label class="fonticon-classname">icon-cc</label>
      <label class="fonticon-unit">f20a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ils"></i></div>
      <label class="fonticon-classname">icon-ils</label>
      <label class="fonticon-unit">f20b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-shekel"></i></div>
      <label class="fonticon-classname">icon-shekel</label>
      <label class="fonticon-unit">f20b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sheqel"></i></div>
      <label class="fonticon-classname">icon-sheqel</label>
      <label class="fonticon-unit">f20b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-meanpath"></i></div>
      <label class="fonticon-classname">icon-meanpath</label>
      <label class="fonticon-unit">f20c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-buysellads"></i></div>
      <label class="fonticon-classname">icon-buysellads</label>
      <label class="fonticon-unit">f20d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-connectdevelop"></i></div>
      <label class="fonticon-classname">icon-connectdevelop</label>
      <label class="fonticon-unit">f20e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-dashcube"></i></div>
      <label class="fonticon-classname">icon-dashcube</label>
      <label class="fonticon-unit">f210</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-forumbee"></i></div>
      <label class="fonticon-classname">icon-forumbee</label>
      <label class="fonticon-unit">f211</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-leanpub"></i></div>
      <label class="fonticon-classname">icon-leanpub</label>
      <label class="fonticon-unit">f212</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sellsy"></i></div>
      <label class="fonticon-classname">icon-sellsy</label>
      <label class="fonticon-unit">f213</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-shirtsinbulk"></i></div>
      <label class="fonticon-classname">icon-shirtsinbulk</label>
      <label class="fonticon-unit">f214</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-simplybuilt"></i></div>
      <label class="fonticon-classname">icon-simplybuilt</label>
      <label class="fonticon-unit">f215</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-skyatlas"></i></div>
      <label class="fonticon-classname">icon-skyatlas</label>
      <label class="fonticon-unit">f216</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cart-plus"></i></div>
      <label class="fonticon-classname">icon-cart-plus</label>
      <label class="fonticon-unit">f217</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cart-arrow-down"></i></div>
      <label class="fonticon-classname">icon-cart-arrow-down</label>
      <label class="fonticon-unit">f218</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-diamond"></i></div>
      <label class="fonticon-classname">icon-diamond</label>
      <label class="fonticon-unit">f219</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-ship"></i></div>
      <label class="fonticon-classname">icon-ship</label>
      <label class="fonticon-unit">f21a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-user-secret"></i></div>
      <label class="fonticon-classname">icon-user-secret</label>
      <label class="fonticon-unit">f21b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-motorcycle"></i></div>
      <label class="fonticon-classname">icon-motorcycle</label>
      <label class="fonticon-unit">f21c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-street-view"></i></div>
      <label class="fonticon-classname">icon-street-view</label>
      <label class="fonticon-unit">f21d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-heartbeat"></i></div>
      <label class="fonticon-classname">icon-heartbeat</label>
      <label class="fonticon-unit">f21e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-venus"></i></div>
      <label class="fonticon-classname">icon-venus</label>
      <label class="fonticon-unit">f221</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mars"></i></div>
      <label class="fonticon-classname">icon-mars</label>
      <label class="fonticon-unit">f222</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mercury"></i></div>
      <label class="fonticon-classname">icon-mercury</label>
      <label class="fonticon-unit">f223</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-intersex"></i></div>
      <label class="fonticon-classname">icon-intersex</label>
      <label class="fonticon-unit">f224</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-transgender2"></i></div>
      <label class="fonticon-classname">icon-transgender2</label>
      <label class="fonticon-unit">f224</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-transgender-alt"></i></div>
      <label class="fonticon-classname">icon-transgender-alt</label>
      <label class="fonticon-unit">f225</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-venus-double"></i></div>
      <label class="fonticon-classname">icon-venus-double</label>
      <label class="fonticon-unit">f226</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mars-double"></i></div>
      <label class="fonticon-classname">icon-mars-double</label>
      <label class="fonticon-unit">f227</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-venus-mars"></i></div>
      <label class="fonticon-classname">icon-venus-mars</label>
      <label class="fonticon-unit">f228</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mars-stroke"></i></div>
      <label class="fonticon-classname">icon-mars-stroke</label>
      <label class="fonticon-unit">f229</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mars-stroke-v"></i></div>
      <label class="fonticon-classname">icon-mars-stroke-v</label>
      <label class="fonticon-unit">f22a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mars-stroke-h"></i></div>
      <label class="fonticon-classname">icon-mars-stroke-h</label>
      <label class="fonticon-unit">f22b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-neuter"></i></div>
      <label class="fonticon-classname">icon-neuter</label>
      <label class="fonticon-unit">f22c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-genderless"></i></div>
      <label class="fonticon-classname">icon-genderless</label>
      <label class="fonticon-unit">f22d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-facebook-official"></i></div>
      <label class="fonticon-classname">icon-facebook-official</label>
      <label class="fonticon-unit">f230</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pinterest-p"></i></div>
      <label class="fonticon-classname">icon-pinterest-p</label>
      <label class="fonticon-unit">f231</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-whatsapp2"></i></div>
      <label class="fonticon-classname">icon-whatsapp2</label>
      <label class="fonticon-unit">f232</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-server"></i></div>
      <label class="fonticon-classname">icon-server</label>
      <label class="fonticon-unit">f233</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-user-plus2"></i></div>
      <label class="fonticon-classname">icon-user-plus2</label>
      <label class="fonticon-unit">f234</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-user-times"></i></div>
      <label class="fonticon-classname">icon-user-times</label>
      <label class="fonticon-unit">f235</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bed"></i></div>
      <label class="fonticon-classname">icon-bed</label>
      <label class="fonticon-unit">f236</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hotel"></i></div>
      <label class="fonticon-classname">icon-hotel</label>
      <label class="fonticon-unit">f236</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-viacoin"></i></div>
      <label class="fonticon-classname">icon-viacoin</label>
      <label class="fonticon-unit">f237</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-train"></i></div>
      <label class="fonticon-classname">icon-train</label>
      <label class="fonticon-unit">f238</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-subway"></i></div>
      <label class="fonticon-classname">icon-subway</label>
      <label class="fonticon-unit">f239</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-medium"></i></div>
      <label class="fonticon-classname">icon-medium</label>
      <label class="fonticon-unit">f23a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-y-combinator"></i></div>
      <label class="fonticon-classname">icon-y-combinator</label>
      <label class="fonticon-unit">f23b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-yc"></i></div>
      <label class="fonticon-classname">icon-yc</label>
      <label class="fonticon-unit">f23b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-optin-monster"></i></div>
      <label class="fonticon-classname">icon-optin-monster</label>
      <label class="fonticon-unit">f23c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-opencart"></i></div>
      <label class="fonticon-classname">icon-opencart</label>
      <label class="fonticon-unit">f23d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-expeditedssl"></i></div>
      <label class="fonticon-classname">icon-expeditedssl</label>
      <label class="fonticon-unit">f23e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-4"></i></div>
      <label class="fonticon-classname">icon-battery-4</label>
      <label class="fonticon-unit">f240</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-full2"></i></div>
      <label class="fonticon-classname">icon-battery-full2</label>
      <label class="fonticon-unit">f240</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-3"></i></div>
      <label class="fonticon-classname">icon-battery-3</label>
      <label class="fonticon-unit">f241</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-three-quarters"></i></div>
      <label class="fonticon-classname">icon-battery-three-quarters</label>
      <label class="fonticon-unit">f241</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-2"></i></div>
      <label class="fonticon-classname">icon-battery-2</label>
      <label class="fonticon-unit">f242</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-half2"></i></div>
      <label class="fonticon-classname">icon-battery-half2</label>
      <label class="fonticon-unit">f242</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-1"></i></div>
      <label class="fonticon-classname">icon-battery-1</label>
      <label class="fonticon-unit">f243</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-quarter"></i></div>
      <label class="fonticon-classname">icon-battery-quarter</label>
      <label class="fonticon-unit">f243</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-0"></i></div>
      <label class="fonticon-classname">icon-battery-0</label>
      <label class="fonticon-unit">f244</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-battery-empty2"></i></div>
      <label class="fonticon-classname">icon-battery-empty2</label>
      <label class="fonticon-unit">f244</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mouse-pointer"></i></div>
      <label class="fonticon-classname">icon-mouse-pointer</label>
      <label class="fonticon-unit">f245</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-i-cursor"></i></div>
      <label class="fonticon-classname">icon-i-cursor</label>
      <label class="fonticon-unit">f246</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-object-group"></i></div>
      <label class="fonticon-classname">icon-object-group</label>
      <label class="fonticon-unit">f247</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-object-ungroup"></i></div>
      <label class="fonticon-classname">icon-object-ungroup</label>
      <label class="fonticon-unit">f248</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sticky-note"></i></div>
      <label class="fonticon-classname">icon-sticky-note</label>
      <label class="fonticon-unit">f249</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sticky-note-o"></i></div>
      <label class="fonticon-classname">icon-sticky-note-o</label>
      <label class="fonticon-unit">f24a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-jcb"></i></div>
      <label class="fonticon-classname">icon-cc-jcb</label>
      <label class="fonticon-unit">f24b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-cc-diners-club"></i></div>
      <label class="fonticon-classname">icon-cc-diners-club</label>
      <label class="fonticon-unit">f24c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-clone"></i></div>
      <label class="fonticon-classname">icon-clone</label>
      <label class="fonticon-unit">f24d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-balance-scale"></i></div>
      <label class="fonticon-classname">icon-balance-scale</label>
      <label class="fonticon-unit">f24e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass-o"></i></div>
      <label class="fonticon-classname">icon-hourglass-o</label>
      <label class="fonticon-unit">f250</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass-1"></i></div>
      <label class="fonticon-classname">icon-hourglass-1</label>
      <label class="fonticon-unit">f251</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass-start"></i></div>
      <label class="fonticon-classname">icon-hourglass-start</label>
      <label class="fonticon-unit">f251</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass-2"></i></div>
      <label class="fonticon-classname">icon-hourglass-2</label>
      <label class="fonticon-unit">f252</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass-half"></i></div>
      <label class="fonticon-classname">icon-hourglass-half</label>
      <label class="fonticon-unit">f252</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass-3"></i></div>
      <label class="fonticon-classname">icon-hourglass-3</label>
      <label class="fonticon-unit">f253</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass-end"></i></div>
      <label class="fonticon-classname">icon-hourglass-end</label>
      <label class="fonticon-unit">f253</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hourglass"></i></div>
      <label class="fonticon-classname">icon-hourglass</label>
      <label class="fonticon-unit">f254</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-grab-o"></i></div>
      <label class="fonticon-classname">icon-hand-grab-o</label>
      <label class="fonticon-unit">f255</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-rock-o"></i></div>
      <label class="fonticon-classname">icon-hand-rock-o</label>
      <label class="fonticon-unit">f255</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-paper-o"></i></div>
      <label class="fonticon-classname">icon-hand-paper-o</label>
      <label class="fonticon-unit">f256</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-stop-o"></i></div>
      <label class="fonticon-classname">icon-hand-stop-o</label>
      <label class="fonticon-unit">f256</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-scissors-o"></i></div>
      <label class="fonticon-classname">icon-hand-scissors-o</label>
      <label class="fonticon-unit">f257</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-lizard-o"></i></div>
      <label class="fonticon-classname">icon-hand-lizard-o</label>
      <label class="fonticon-unit">f258</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-spock-o"></i></div>
      <label class="fonticon-classname">icon-hand-spock-o</label>
      <label class="fonticon-unit">f259</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-pointer-o"></i></div>
      <label class="fonticon-classname">icon-hand-pointer-o</label>
      <label class="fonticon-unit">f25a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hand-peace-o"></i></div>
      <label class="fonticon-classname">icon-hand-peace-o</label>
      <label class="fonticon-unit">f25b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-trademark"></i></div>
      <label class="fonticon-classname">icon-trademark</label>
      <label class="fonticon-unit">f25c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-registered"></i></div>
      <label class="fonticon-classname">icon-registered</label>
      <label class="fonticon-unit">f25d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-creative-commons"></i></div>
      <label class="fonticon-classname">icon-creative-commons</label>
      <label class="fonticon-unit">f25e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gg"></i></div>
      <label class="fonticon-classname">icon-gg</label>
      <label class="fonticon-unit">f260</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gg-circle"></i></div>
      <label class="fonticon-classname">icon-gg-circle</label>
      <label class="fonticon-unit">f261</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tripadvisor"></i></div>
      <label class="fonticon-classname">icon-tripadvisor</label>
      <label class="fonticon-unit">f262</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-odnoklassniki"></i></div>
      <label class="fonticon-classname">icon-odnoklassniki</label>
      <label class="fonticon-unit">f263</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-odnoklassniki-square"></i></div>
      <label class="fonticon-classname">icon-odnoklassniki-square</label>
      <label class="fonticon-unit">f264</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-get-pocket"></i></div>
      <label class="fonticon-classname">icon-get-pocket</label>
      <label class="fonticon-unit">f265</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wikipedia-w"></i></div>
      <label class="fonticon-classname">icon-wikipedia-w</label>
      <label class="fonticon-unit">f266</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-safari2"></i></div>
      <label class="fonticon-classname">icon-safari2</label>
      <label class="fonticon-unit">f267</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-chrome2"></i></div>
      <label class="fonticon-classname">icon-chrome2</label>
      <label class="fonticon-unit">f268</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-firefox2"></i></div>
      <label class="fonticon-classname">icon-firefox2</label>
      <label class="fonticon-unit">f269</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-opera2"></i></div>
      <label class="fonticon-classname">icon-opera2</label>
      <label class="fonticon-unit">f26a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-internet-explorer"></i></div>
      <label class="fonticon-classname">icon-internet-explorer</label>
      <label class="fonticon-unit">f26b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-television"></i></div>
      <label class="fonticon-classname">icon-television</label>
      <label class="fonticon-unit">f26c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-tv3"></i></div>
      <label class="fonticon-classname">icon-tv3</label>
      <label class="fonticon-unit">f26c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-contao"></i></div>
      <label class="fonticon-classname">icon-contao</label>
      <label class="fonticon-unit">f26d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-500px2"></i></div>
      <label class="fonticon-classname">icon-500px2</label>
      <label class="fonticon-unit">f26e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-amazon2"></i></div>
      <label class="fonticon-classname">icon-amazon2</label>
      <label class="fonticon-unit">f270</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-calendar-plus-o"></i></div>
      <label class="fonticon-classname">icon-calendar-plus-o</label>
      <label class="fonticon-unit">f271</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-calendar-minus-o"></i></div>
      <label class="fonticon-classname">icon-calendar-minus-o</label>
      <label class="fonticon-unit">f272</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-calendar-times-o"></i></div>
      <label class="fonticon-classname">icon-calendar-times-o</label>
      <label class="fonticon-unit">f273</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-calendar-check-o"></i></div>
      <label class="fonticon-classname">icon-calendar-check-o</label>
      <label class="fonticon-unit">f274</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-industry"></i></div>
      <label class="fonticon-classname">icon-industry</label>
      <label class="fonticon-unit">f275</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-map-pin"></i></div>
      <label class="fonticon-classname">icon-map-pin</label>
      <label class="fonticon-unit">f276</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-map-signs"></i></div>
      <label class="fonticon-classname">icon-map-signs</label>
      <label class="fonticon-unit">f277</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-map-o"></i></div>
      <label class="fonticon-classname">icon-map-o</label>
      <label class="fonticon-unit">f278</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-map5"></i></div>
      <label class="fonticon-classname">icon-map5</label>
      <label class="fonticon-unit">f279</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-commenting"></i></div>
      <label class="fonticon-classname">icon-commenting</label>
      <label class="fonticon-unit">f27a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-commenting-o"></i></div>
      <label class="fonticon-classname">icon-commenting-o</label>
      <label class="fonticon-unit">f27b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-houzz"></i></div>
      <label class="fonticon-classname">icon-houzz</label>
      <label class="fonticon-unit">f27c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-vimeo3"></i></div>
      <label class="fonticon-classname">icon-vimeo3</label>
      <label class="fonticon-unit">f27d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-black-tie"></i></div>
      <label class="fonticon-classname">icon-black-tie</label>
      <label class="fonticon-unit">f27e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fonticons"></i></div>
      <label class="fonticon-classname">icon-fonticons</label>
      <label class="fonticon-unit">f280</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-reddit-alien"></i></div>
      <label class="fonticon-classname">icon-reddit-alien</label>
      <label class="fonticon-unit">f281</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-edge2"></i></div>
      <label class="fonticon-classname">icon-edge2</label>
      <label class="fonticon-unit">f282</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-credit-card-alt"></i></div>
      <label class="fonticon-classname">icon-credit-card-alt</label>
      <label class="fonticon-unit">f283</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-codiepie"></i></div>
      <label class="fonticon-classname">icon-codiepie</label>
      <label class="fonticon-unit">f284</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-modx"></i></div>
      <label class="fonticon-classname">icon-modx</label>
      <label class="fonticon-unit">f285</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fort-awesome"></i></div>
      <label class="fonticon-classname">icon-fort-awesome</label>
      <label class="fonticon-unit">f286</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-usb3"></i></div>
      <label class="fonticon-classname">icon-usb3</label>
      <label class="fonticon-unit">f287</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-product-hunt"></i></div>
      <label class="fonticon-classname">icon-product-hunt</label>
      <label class="fonticon-unit">f288</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-mixcloud"></i></div>
      <label class="fonticon-classname">icon-mixcloud</label>
      <label class="fonticon-unit">f289</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-scribd"></i></div>
      <label class="fonticon-classname">icon-scribd</label>
      <label class="fonticon-unit">f28a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pause-circle"></i></div>
      <label class="fonticon-classname">icon-pause-circle</label>
      <label class="fonticon-unit">f28b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pause-circle-o"></i></div>
      <label class="fonticon-classname">icon-pause-circle-o</label>
      <label class="fonticon-unit">f28c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stop-circle"></i></div>
      <label class="fonticon-classname">icon-stop-circle</label>
      <label class="fonticon-unit">f28d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-stop-circle-o"></i></div>
      <label class="fonticon-classname">icon-stop-circle-o</label>
      <label class="fonticon-unit">f28e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-shopping-bag"></i></div>
      <label class="fonticon-classname">icon-shopping-bag</label>
      <label class="fonticon-unit">f290</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-shopping-basket"></i></div>
      <label class="fonticon-classname">icon-shopping-basket</label>
      <label class="fonticon-unit">f291</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hashtag"></i></div>
      <label class="fonticon-classname">icon-hashtag</label>
      <label class="fonticon-unit">f292</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bluetooth2"></i></div>
      <label class="fonticon-classname">icon-bluetooth2</label>
      <label class="fonticon-unit">f293</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-bluetooth-b"></i></div>
      <label class="fonticon-classname">icon-bluetooth-b</label>
      <label class="fonticon-unit">f294</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-percent"></i></div>
      <label class="fonticon-classname">icon-percent</label>
      <label class="fonticon-unit">f295</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-gitlab"></i></div>
      <label class="fonticon-classname">icon-gitlab</label>
      <label class="fonticon-unit">f296</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wpbeginner"></i></div>
      <label class="fonticon-classname">icon-wpbeginner</label>
      <label class="fonticon-unit">f297</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wpforms"></i></div>
      <label class="fonticon-classname">icon-wpforms</label>
      <label class="fonticon-unit">f298</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-envira"></i></div>
      <label class="fonticon-classname">icon-envira</label>
      <label class="fonticon-unit">f299</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-universal-access"></i></div>
      <label class="fonticon-classname">icon-universal-access</label>
      <label class="fonticon-unit">f29a</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-wheelchair-alt"></i></div>
      <label class="fonticon-classname">icon-wheelchair-alt</label>
      <label class="fonticon-unit">f29b</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-question-circle-o"></i></div>
      <label class="fonticon-classname">icon-question-circle-o</label>
      <label class="fonticon-unit">f29c</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-blind"></i></div>
      <label class="fonticon-classname">icon-blind</label>
      <label class="fonticon-unit">f29d</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-audio-description"></i></div>
      <label class="fonticon-classname">icon-audio-description</label>
      <label class="fonticon-unit">f29e</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-volume-control-phone"></i></div>
      <label class="fonticon-classname">icon-volume-control-phone</label>
      <label class="fonticon-unit">f2a0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-braille"></i></div>
      <label class="fonticon-classname">icon-braille</label>
      <label class="fonticon-unit">f2a1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-assistive-listening-systems"></i></div>
      <label class="fonticon-classname">icon-assistive-listening-systems</label>
      <label class="fonticon-unit">f2a2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-american-sign-language-interpreting"></i></div>
      <label class="fonticon-classname">icon-american-sign-language-interpreting</label>
      <label class="fonticon-unit">f2a3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-asl-interpreting"></i></div>
      <label class="fonticon-classname">icon-asl-interpreting</label>
      <label class="fonticon-unit">f2a3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-deaf"></i></div>
      <label class="fonticon-classname">icon-deaf</label>
      <label class="fonticon-unit">f2a4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-deafness"></i></div>
      <label class="fonticon-classname">icon-deafness</label>
      <label class="fonticon-unit">f2a4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-hard-of-hearing"></i></div>
      <label class="fonticon-classname">icon-hard-of-hearing</label>
      <label class="fonticon-unit">f2a4</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-glide"></i></div>
      <label class="fonticon-classname">icon-glide</label>
      <label class="fonticon-unit">f2a5</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-glide-g"></i></div>
      <label class="fonticon-classname">icon-glide-g</label>
      <label class="fonticon-unit">f2a6</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-sign-language"></i></div>
      <label class="fonticon-classname">icon-sign-language</label>
      <label class="fonticon-unit">f2a7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-signing"></i></div>
      <label class="fonticon-classname">icon-signing</label>
      <label class="fonticon-unit">f2a7</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-low-vision"></i></div>
      <label class="fonticon-classname">icon-low-vision</label>
      <label class="fonticon-unit">f2a8</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-viadeo"></i></div>
      <label class="fonticon-classname">icon-viadeo</label>
      <label class="fonticon-unit">f2a9</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-viadeo-square"></i></div>
      <label class="fonticon-classname">icon-viadeo-square</label>
      <label class="fonticon-unit">f2aa</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-snapchat"></i></div>
      <label class="fonticon-classname">icon-snapchat</label>
      <label class="fonticon-unit">f2ab</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-snapchat-ghost"></i></div>
      <label class="fonticon-classname">icon-snapchat-ghost</label>
      <label class="fonticon-unit">f2ac</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-snapchat-square"></i></div>
      <label class="fonticon-classname">icon-snapchat-square</label>
      <label class="fonticon-unit">f2ad</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-pied-piper"></i></div>
      <label class="fonticon-classname">icon-pied-piper</label>
      <label class="fonticon-unit">f2ae</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-first-order"></i></div>
      <label class="fonticon-classname">icon-first-order</label>
      <label class="fonticon-unit">f2b0</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-yoast"></i></div>
      <label class="fonticon-classname">icon-yoast</label>
      <label class="fonticon-unit">f2b1</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-themeisle"></i></div>
      <label class="fonticon-classname">icon-themeisle</label>
      <label class="fonticon-unit">f2b2</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-google-plus-circle"></i></div>
      <label class="fonticon-classname">icon-google-plus-circle</label>
      <label class="fonticon-unit">f2b3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-google-plus-official"></i></div>
      <label class="fonticon-classname">icon-google-plus-official</label>
      <label class="fonticon-unit">f2b3</label>
    </div>
    <div class="col-md-3 ">
      <div class="fonticon-wrap"><i class="icon-fa"></i></div>
      <label class="fonticon-classname">icon-fa</label>
      <label class="fonticon-unit">f2b4</label>
    </div>
</div>
<script type="text/javascript">
      $(function(){
             $('.fonticon-unit').remove()     
      })
     
</script>
<style type="text/css">
      .fonticon-wrap { 
            text-align: center; 
            font-size: 20px;
            cursor: pointer;
      }
      .fonticon-classname { 
            font-size: 11px;
            width: 100%;
      }

</style>